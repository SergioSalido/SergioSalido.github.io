@echo off
setlocal
set "APP=%~dp0programa"
if not exist "%APP%\requirements.txt" goto incompleto
if not exist "%APP%\app.py" goto incompleto
if not exist "%APP%\descargar_modelo.py" goto incompleto
pushd "%APP%" || goto incompleto
title EclipseBot - Instalar y abrir
if exist ".venv\Scripts\python.exe" goto checkenv
:findpython
py -3.12 -c "import tkinter" >nul 2>&1
if not errorlevel 1 (
 py -3.12 -m venv .venv
 goto checkenv
)
py -3.11 -c "import tkinter" >nul 2>&1
if not errorlevel 1 (
 py -3.11 -m venv .venv
 goto checkenv
)
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
 "%LocalAppData%\Programs\Python\Python312\python.exe" -m venv .venv
 goto checkenv
)
where winget >nul 2>&1
if errorlevel 1 goto nopython
echo [1/4] Instalando Python 3.12 para tu usuario...
winget install --id Python.Python.3.12 --exact --source winget --scope user --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto nopython
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
 "%LocalAppData%\Programs\Python\Python312\python.exe" -m venv .venv
 goto checkenv
)
echo Cierra esta ventana y vuelve a pulsar ABRIR_ECLIPSEBOT.bat.
pause
exit /b 1
:checkenv
if not exist ".venv\Scripts\python.exe" goto fail
".venv\Scripts\python.exe" -c "import tkinter" >nul 2>&1
if errorlevel 1 goto fail
if exist ".venv\eclipsebot_ready" goto launch
 echo [2/4] Instalando componentes de EclipseBot...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r "%APP%\requirements.txt"
if errorlevel 1 goto fail
echo [3/4] Descargando modelo de voz local...
".venv\Scripts\python.exe" "%APP%\descargar_modelo.py"
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m unittest discover -q
if errorlevel 1 goto fail
type nul > ".venv\eclipsebot_ready"
:launch
echo Abriendo EclipseBot...
if not exist ".venv\Scripts\pythonw.exe" goto fail
start "" ".venv\Scripts\pythonw.exe" "%APP%\app.py"
if errorlevel 1 goto fail
exit /b 0
:nopython
echo No se pudo instalar Python automaticamente. Puede que este PC tenga restricciones.
echo Instala Python 3.12 desde https://www.python.org/downloads/windows/ y vuelve a abrir este archivo.
pause
exit /b 1
:fail
echo No se pudo completar la instalacion o abrir EclipseBot. Revisa el error anterior.
pause
exit /b 1

:incompleto
echo ERROR: Faltan archivos de EclipseBot.
echo Extrae TODO el ZIP con clic derecho - Extraer todo.
echo Abre este BAT desde la carpeta extraida, junto a la carpeta programa.
pause
exit /b 1
