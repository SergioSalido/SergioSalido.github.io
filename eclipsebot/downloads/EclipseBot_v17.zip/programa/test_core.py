import unittest
from core import matches, Cooldown, DEFAULT_MESSAGE

class TestCore(unittest.TestCase):
    def test_frase(self):
        self.assertTrue(matches('Uníos a mi DISCORD!', 'Discord, discor, dis cord'))
        self.assertTrue(matches('mi dis cord', 'Discord, discor, dis cord'))
        self.assertFalse(matches('discordia', 'Discord, discor'))
        self.assertFalse(matches('vamos a jugar', 'Discord, discor'))
    def test_cooldown(self):
        now=[0]; c=Cooldown(lambda:now[0]); self.assertEqual(c.remaining('real',60),0)
        c.mark('real'); now[0]=30; self.assertEqual(c.remaining('real',60),30)
        self.assertEqual(c.remaining('test',60),0); now[0]=60; self.assertEqual(c.remaining('real',60),0)
    def test_link(self): self.assertEqual(DEFAULT_MESSAGE,'')

if __name__=='__main__': unittest.main()
