import unittest
from unittest.mock import Mock, patch
from twitch import Twitch, TwitchError
from twitch_alerts import subscriptions
from core import SCOPE

class OwnerTests(unittest.TestCase):
    def session(self, login='streamer_demo', uid='123'):
        obj=Twitch('client');obj.token='fake'
        with patch('twitch.requests.get') as get:
            get.return_value=Mock(ok=True)
            get.return_value.json.return_value={'client_id':'client','scopes':SCOPE.split(),'user_id':uid,'login':login}
            obj.validate()
        return obj
    def test_owner_and_sender_match_for_any_account(self):
        for login,uid in [('streamer_demo','123'),('other_streamer','456')]:
            obj=self.session(login,uid)
            self.assertEqual(obj.broadcaster,uid)
            self.assertEqual(obj.sender,uid)
            self.assertEqual(obj.login,login)
            for _,_,condition in subscriptions(obj):
                self.assertTrue(all(value==uid for value in condition.values()))
    def test_message_targets_authorized_account(self):
        obj=self.session()
        with patch.object(obj,'maintain'),patch('twitch.requests.post') as post:
            post.return_value=Mock(ok=True)
            post.return_value.json.return_value={'data':[{'is_sent':True,'message_id':'m'}]}
            self.assertEqual(obj.send('hola'),'m')
            self.assertEqual(post.call_args.kwargs['json'],{'broadcaster_id':'123','sender_id':'123','message':'hola'})
            post.return_value.json.return_value={'data':[{'is_sent':False,'drop_reason':{'code':'blocked'}}]}
            with self.assertRaises(TwitchError):obj.send('hola')
