"""Local alert box with independent preview and bounded event queue."""
import json, time, threading, shutil, uuid, mimetypes, webbrowser, re
from pathlib import Path
from user_data import DATA_DIR
from collections import deque
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import font as tkfont
BASE=DATA_DIR
EVENTS={'tw-follow':('Twitch · Seguidor','¡Gracias por seguirme, {user}!','✦','#ad79ff'), 'tw-sub':('Twitch · Suscripción','¡Gracias por la sub, {user}!','★','#ad79ff'), 'tw-resub':('Twitch · Resuscripción','¡{user}, {count} meses de apoyo!','★','#ad79ff'), 'tw-gift':('Twitch · Regalo de subs','¡{user} ha regalado {count} subs!','🎁','#ad79ff'), 'tw-bits':('Twitch · Bits','¡{user} ha enviado {count} bits!','◆','#ad79ff'), 'tw-raid':('Twitch · Raid','¡{user} llega con {count} espectadores!','⚡','#ad79ff'), 'tt-follow':('TikTok · Seguidor','¡Gracias por seguirme, {user}!','✦','#26e9df'), 'tt-gift':('TikTok · Regalo','¡{user} ha enviado {count} × {gift}!','🎁','#26e9df')}
MEDIA={'gif':{'.gif','.png','.jpg','.jpeg','.webp'},'sound':{'.mp3','.wav','.ogg'}}
def valid_color(value, fallback):
 return value if isinstance(value,str) and re.fullmatch(r'#[0-9a-fA-F]{6}',value) else fallback

class Alerts:
 def __init__(self,root=BASE):
  self.root=Path(root);self.media=self.root/'alert_media';self.media.mkdir(exist_ok=True);self.lock=threading.Lock();self.seq=0;self.events=deque(maxlen=100);self.settings={}
  try:self.settings=json.loads((self.root/'alerts.json').read_text())
  except (OSError,ValueError):pass
  if not isinstance(self.settings,dict):self.settings={}
 def config(self,key):
  d={'enabled':True,'message':EVENTS[key][1],'gif':'','sound':'','duration':6,'volume':60,'color':EVENTS[key][3]};v=self.settings.get(key,{})
  if isinstance(v,dict):d.update(v)
  d['color']=valid_color(d.get('color'),EVENTS[key][3])
  d['frame_color']=valid_color(d.get('frame_color'),d['color'])
  d['title_color']=valid_color(d.get('title_color'),d['color'])
  d['text_color']=valid_color(d.get('text_color'),'#ffffff')
  return d
 def save(self,key,cfg):
  with self.lock:
   self.settings[key]=cfg;tmp=self.root/'alerts.tmp';tmp.write_text(json.dumps(self.settings,ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(self.root/'alerts.json')
 def import_media(self,kind,path):
  p=Path(path);ext=p.suffix.lower()
  if ext not in MEDIA[kind] or p.stat().st_size>30*1024*1024:raise ValueError('Formato no permitido o archivo superior a 30 MB.')
  name=uuid.uuid4().hex+ext;shutil.copyfile(p,self.media/name);return name
 def make(self,key,user,count=1,gift='regalo'):
  cfg=self.config(key);msg=str(cfg['message'])[:400]
  for k,v in [('user',user),('count',count),('gift',gift),('platform',EVENTS[key][0].split(' · ')[0])]:msg=msg.replace('{'+k+'}',str(v)[:120])
  return dict(cfg,title=EVENTS[key][0],icon=EVENTS[key][2],text=msg)
 def emit(self,key,user,count=1,gift='regalo'):
  if key not in EVENTS:return
  with self.lock:
   d=self.make(key,user,count,gift)
   if not d['enabled']:return
   self.seq+=1;self.events.append(dict(d,id=self.seq,created=time.time()))
 def snapshot(self,after):
  with self.lock:return {'cursor':self.seq,'events':[] if after<0 else [e for e in self.events if e['id']>after and time.time()-e['created']<45]}
 def route(self,path,query):
  from urllib.parse import parse_qs
  if path==['alerts']:return page(False).encode(),'text/html; charset=utf-8'
  if path==['alert-preview']:
   key=parse_qs(query).get('event',['tw-follow'])[0];return page(True,key if key in EVENTS else 'tw-follow').encode(),'text/html; charset=utf-8'
  if path==['alert-data']:
   try:after=int(parse_qs(query).get('after',['-1'])[0])
   except ValueError:after=-1
   return json.dumps(self.snapshot(after)).encode(),'application/json'
  if len(path)==2 and path[0]=='alert-sample' and path[1] in EVENTS:return json.dumps(self.make(path[1],'EspectadorDemo',5,'Rosa')).encode(),'application/json'
  if len(path)==2 and path[0]=='alert-media':
   import re
   if not re.fullmatch(r'[0-9a-f]{32}\.(gif|png|jpg|jpeg|webp|mp3|wav|ogg)',path[1]):return
   p=self.media/path[1]
   if p.is_file():return p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream'

def page(demo,key='tw-follow'):
 return '''<!doctype html><html lang="es"><meta charset="utf-8"><style>
 *{box-sizing:border-box}body{margin:0;background:transparent;color:#fff;font-family:Segoe UI,Arial;display:grid;place-items:center;height:100vh;overflow:hidden}#box{--a:#ff3448;--frame:#ff3448;--title:#ff3448;--text:#ffffff;width:min(88vw,720px);text-align:center;opacity:0;transform:scale(.88);transition:opacity .35s,transform .35s;filter:drop-shadow(0 0 18px color-mix(in srgb,var(--frame) 55%,transparent))}#box.on{opacity:1;transform:scale(1)}#art{height:185px;display:grid;place-items:center;font-size:100px;color:var(--a);text-shadow:0 0 30px var(--a)}#art img{max-height:185px;max-width:95%;object-fit:contain}.frame{padding:3px;background:linear-gradient(125deg,#bfc5cf,var(--frame),#262630,var(--frame));clip-path:polygon(0 20%,5% 0,95% 0,100% 20%,100% 80%,95% 100%,5% 100%,0 80%)}.inside{padding:24px 28px 28px;background:repeating-linear-gradient(125deg,#181920 0 2px,#111218 2px 5px);clip-path:polygon(0 20%,5% 0,95% 0,100% 20%,100% 80%,95% 100%,5% 100%,0 80%)}#title{font-size:16px;font-weight:900;letter-spacing:3px;color:var(--title);text-transform:uppercase;font-style:italic}#msg{color:var(--text);font-size:32px;font-weight:900;font-style:italic;overflow-wrap:anywhere;margin:10px 0}.line{height:2px;background:linear-gradient(90deg,transparent,var(--frame),transparent);margin-top:15px}#test{position:absolute;top:8px;left:8px;background:#222;color:white;border:1px solid #888;padding:8px;cursor:pointer}
 </style><body><div id="box"><div id="art"></div><div class="frame"><div class="inside"><div id="title"></div><div id="msg"></div><div class="line"></div></div></div></div><script>
 const demo='''+json.dumps(demo)+''',key='''+json.dumps(key)+''';const box=document.getElementById('box'),art=document.getElementById('art');let cursor=-1,q=[],busy=false,audio=null;const sleep=n=>new Promise(r=>setTimeout(r,n));async function show(d){busy=true;box.style.setProperty('--a',d.color);box.style.setProperty('--frame',d.frame_color);box.style.setProperty('--title',d.title_color);box.style.setProperty('--text',d.text_color);art.replaceChildren();if(d.gif){let img=new Image();img.src='/alert-media/'+encodeURIComponent(d.gif);img.onerror=()=>{art.textContent=d.icon};art.append(img)}else art.textContent=d.icon;document.getElementById('title').textContent=d.title;document.getElementById('msg').textContent=d.text;box.classList.add('on');if(d.sound){audio=new Audio('/alert-media/'+encodeURIComponent(d.sound));audio.volume=Math.max(0,Math.min(1,d.volume/100));audio.play().catch(()=>{})}await sleep(Math.max(2,Math.min(30,d.duration))*1000);box.classList.remove('on');if(audio){audio.pause();audio=null}await sleep(450);busy=false}async function tick(){try{let d=await(await fetch('/alert-data?after='+cursor,{cache:'no-store'})).json();cursor=d.cursor;q.push(...d.events);q=q.slice(-25);if(!busy&&q.length)show(q.shift())}catch(e){cursor=-1;q=[]}setTimeout(tick,350)}if(demo){let b=document.createElement('button');b.id='test';b.textContent='▶ Reproducir prueba (con sonido)';b.onclick=async()=>{if(!busy)show(await(await fetch('/alert-sample/'+key)).json())};document.body.append(b)}else tick();</script></body></html>'''

class AlertGallery:
 def __init__(self,app,p):
  self.app=app;self.service=app.overlay_server.alerts;self.key='tw-follow';self.vars={};self.files={};self.rows={};self.loading=False
  app.head(p,'Alertas del directo','Configura eventos activos · TikTok LIVE aparece como próximamente')
  self.status=tk.StringVar();app.label(p,var=self.status,size=10).pack(side='bottom',anchor='w',pady=5)
  actions=tk.Frame(p,bg=p.cget('bg'));actions.pack(side='bottom',fill='x',pady=6)
  for title,fn in [('Guardar',self.save),('Probar alerta',self.preview),('Copiar URL',self.copy)]:app.btn(actions,title,fn,title=='Guardar').pack(side='left',padx=(0,8))
  body=tk.Frame(p,bg=p.cget('bg'));body.pack(fill='both',expand=True)
  left=tk.Frame(body,bg='#211318',padx=9,pady=9,highlightthickness=1,highlightbackground='#ff3448');left.pack(side='left',fill='y',padx=(0,10))
  app.label(left,'TIPOS DE ALERTA',13,bold=True).pack(anchor='w',pady=(3,10))
  for key,(title,_,symbol,color) in EVENTS.items():
   unavailable=key.startswith('tt-');row_bg='#28292e' if unavailable else '#30232e';muted='#85878d'
   r=tk.Frame(left,bg=row_bg,padx=3,pady=3,highlightthickness=0);r.pack(fill='x',pady=3)
   shown=symbol+'  '+title+(' · PRÓXIMAMENTE' if unavailable else '')
   b=tk.Button(r,text=shown,anchor='w',font=tkfont.Font(root=app,family='Segoe UI',size=10,weight='bold',slant='italic',overstrike=1) if unavailable else ('Segoe UI',10,'bold italic'),fg=muted if unavailable else color,bg=row_bg,disabledforeground=muted,activebackground='#535c70',activeforeground='white',bd=0,highlightthickness=0 if unavailable else 1,highlightbackground=row_bg,cursor='arrow' if unavailable else 'hand2',state='disabled' if unavailable else 'normal',command=lambda k=key:self.switch(k));b.pack(side='left',fill='x',expand=True)
   if not unavailable:
    b.bind('<Enter>',lambda e,button=b:button.configure(bg='#494a51',highlightbackground='#92949b'))
    b.bind('<Leave>',lambda e,button=b,normal=row_bg:button.configure(bg=normal,highlightbackground=normal))
   else:
    r.bind('<Enter>',lambda e,row=r:row.configure(highlightthickness=1,highlightbackground='#777980'))
    r.bind('<Leave>',lambda e,row=r:row.configure(highlightthickness=0))
   v=tk.BooleanVar(value=False if unavailable else self.service.config(key)['enabled']);cb=ttk.Checkbutton(r,variable=v,command=lambda k=key:self.toggle(k),state='disabled' if unavailable else 'normal');cb.pack(side='right');self.rows[key]=(r,b,v)
  outer=tk.Frame(body,bg=p.cget('bg'));outer.pack(side='left',fill='both',expand=True)
  canvas=tk.Canvas(outer,bg=p.cget('bg'),highlightthickness=0);scroll=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview);scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True);canvas.configure(yscrollcommand=scroll.set)
  right=tk.Frame(canvas,bg=p.cget('bg'));win=canvas.create_window((0,0),window=right,anchor='nw');right.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win,width=e.width))
  def wheel(e):canvas.yview_scroll(-1 if e.delta>0 or getattr(e,'num',0)==4 else 1,'units')
  def bindwheel(w):
   w.bind('<MouseWheel>',wheel,add='+');w.bind('<Button-4>',wheel,add='+');w.bind('<Button-5>',wheel,add='+')
   for ch in w.winfo_children():bindwheel(ch)
  self.title=tk.StringVar();f=app.card(right,'EVENTO SELECCIONADO');app.label(f,var=self.title,size=17,bold=True).pack(anchor='w');self.vars['enabled']=tk.BooleanVar();ttk.Checkbutton(f,text='Activar alerta',variable=self.vars['enabled'],command=self.update_preview).pack(anchor='w')
  pair=tk.Frame(right,bg=right.cget('bg'));pair.pack(fill='x');pair.columnconfigure(0,weight=1,uniform='pair');pair.columnconfigure(1,weight=1,uniform='pair')
  a=tk.Frame(pair,bg=right.cget('bg'));a.grid(row=0,column=0,sticky='nsew',padx=(0,6));b=tk.Frame(pair,bg=right.cget('bg'));b.grid(row=0,column=1,sticky='nsew')
  f=app.card(a,'VISTA PREVIA · EJEMPLO');self.art=tk.Canvas(f,height=220,bg='#09090c',highlightthickness=0);self.art.pack(fill='x');self.art.bind('<Configure>',lambda e:self.update_preview());app.label(f,'Prueba animada y sonido: botón Probar alerta.',9).pack(anchor='w',pady=5)
  f=app.card(b,'MENSAJE');self.vars['message']=tk.StringVar();self.entry=ttk.Entry(f,textvariable=self.vars['message']);self.entry.pack(fill='x',pady=6)
  for k,t,lo,hi in [('duration','Duración (segundos)',2,30),('volume','Volumen (%)',0,100)]:
   self.vars[k]=tk.IntVar();r=app.row(f);app.label(r,t,10).pack(side='left');app.label(r,var=self.vars[k],size=11,bold=True).pack(side='right');tk.Scale(f,from_=lo,to=hi,orient='horizontal',variable=self.vars[k],showvalue=False,bg=f.cget('bg'),fg='white',highlightthickness=0,troughcolor='#30232e',activebackground='#ff3448',bd=0).pack(fill='x')
  f=app.card(right,'COLORES DE LA ALERTA')
  for k,t in [('frame_color','Color del marco'),('title_color','Color del título (tipo de evento)'),('text_color','Color del mensaje'),('color','Color del icono')]:
   self.vars[k]=tk.StringVar();r=app.row(f);app.label(r,t,10).pack(side='left');app.btn(r,'Elegir',lambda k=k:self.choose_color(k)).pack(side='right');ttk.Entry(r,textvariable=self.vars[k],width=9).pack(side='right',padx=6)
  f=app.card(right,'MULTIMEDIA');r=app.row(f)
  for k,t in [('gif','GIF / imagen'),('sound','Sonido')]:
   box=tk.Frame(r,bg='#30232e',padx=9,pady=8,highlightthickness=1,highlightbackground='#ff3448');box.pack(side='left',fill='both',expand=True,padx=(0,6));self.files[k]=tk.StringVar();app.label(box,t,12,bold=True).pack(anchor='w');app.label(box,var=self.files[k],size=8).pack(anchor='w');br=app.row(box);app.btn(br,'Seleccionar archivo',lambda k=k:self.pick(k)).pack(side='left');app.btn(br,'Quitar',lambda k=k:self.files[k].set('')).pack(side='left',padx=4)
  f=app.card(right,'VARIABLES DISPONIBLES');r=app.row(f)
  for token in ('{user}','{count}','{gift}','{platform}'):
   app.btn(r,token,lambda t=token:self.entry.insert('insert',t)).pack(side='left',padx=(0,4))
  for v in [*self.vars.values(),*self.files.values()]:v.trace_add('write',lambda *_:self.update_preview())
  bindwheel(right);self.load(self.key)
 def choose_color(self,key):
  from tkinter import colorchooser
  color=colorchooser.askcolor(color=valid_color(self.vars[key].get(),'#ffffff'),parent=self.app)[1]
  if color:self.vars[key].set(color)
 def switch(self,key):
  if key.startswith('tt-'):
   self.status.set('TikTok LIVE · PRÓXIMAMENTE');return
  if key==self.key:return
  if self.save():self.load(key)
 def toggle(self,key):
  if key.startswith('tt-'):return
  v=self.rows[key][2].get()
  if key==self.key:self.vars['enabled'].set(v);self.save()
  else:
   c=self.service.config(key);c['enabled']=v;self.service.save(key,c)
 def load(self,key):
  self.loading=True;self.key=key;c=self.service.config(key);self.title.set(EVENTS[key][0].upper())
  for k,v in {**self.vars,**self.files}.items():v.set(c[k])
  for k,(r,b,v) in self.rows.items():v.set(self.service.config(k)['enabled']);r.configure(highlightthickness=1 if k==key else 0,highlightbackground=EVENTS[k][3]);b.configure(relief='groove' if k==key else 'flat')
  self.loading=False;self.update_preview();self.status.set('Editando '+EVENTS[key][0])
 def update_preview(self):
  if self.loading or not hasattr(self,'art') or not self.files:return
  import re
  from PIL import Image,ImageTk
  c=self.art;c.delete('all');w=max(c.winfo_width(),260);h=220;x=w/2;col=self.vars['color'].get();col=valid_color(col,EVENTS[self.key][3]);frame=valid_color(self.vars['frame_color'].get(),col);title=valid_color(self.vars['title_color'].get(),col);text=valid_color(self.vars['text_color'].get(),'#ffffff')
  for r in range(64,40,-3):
   a=tuple(int(col[i:i+2],16) for i in (1,3,5));intensity=(65-r)/35;shade='#'+''.join(f'{int(10+v*intensity*.65):02x}' for v in a);c.create_oval(x-r,62-r,x+r,62+r,outline=shade,width=3)
  c.create_oval(x-42,20,x+42,104,fill='#16131b',outline=col,width=2)
  c.create_text(x,62,text=EVENTS[self.key][2],fill=col,font=('Segoe UI',34,'bold'))
  if self.files['gif'].get():
   try:
    with Image.open(self.service.media/self.files['gif'].get()) as img:img.thumbnail((w-30,100));self.photo=ImageTk.PhotoImage(img.copy());c.create_image(x,61,image=self.photo)
   except (OSError,ValueError):pass
  points=(10,137,26,117,w-26,117,w-10,137,w-10,190,w-26,207,26,207,10,190)
  c.create_polygon(points,fill='#1c1018',outline=frame,width=3);c.create_text(x,137,text=EVENTS[self.key][0].upper(),fill=title,font=('Segoe UI',10,'bold italic'))
  msg=self.vars['message'].get().replace('{user}','EspectadorDemo').replace('{count}','5').replace('{gift}','Rosa').replace('{platform}',EVENTS[self.key][0].split(' · ')[0]);c.create_text(x,170,text=msg,fill=text,font=('Segoe UI',12,'bold italic'),width=w-48,justify='center')
 def pick(self,k):
  p=filedialog.askopenfilename(filetypes=[('Archivos compatibles',' '.join('*'+x for x in sorted(MEDIA[k])))])
  if p:
   try:self.files[k].set(self.service.import_media(k,p))
   except (OSError,ValueError) as e:messagebox.showerror('Alertas',str(e))
 def save(self):
  import re
  try:
   c={k:v.get() for k,v in {**self.vars,**self.files}.items()};c['duration']=int(c['duration']);c['volume']=int(c['volume']);assert 2<=c['duration']<=30 and 0<=c['volume']<=100 and all(re.fullmatch('#[a-fA-F0-9]{6}',c[k]) for k in ('color','frame_color','title_color','text_color'));self.service.save(self.key,c);self.rows[self.key][2].set(c['enabled']);self.status.set('Guardado · cambios para próximas alertas.');return True
  except (ValueError,AssertionError,OSError,tk.TclError):self.status.set('Revisa duración, volumen y color (#RRGGBB).');return False
 def preview(self):
  if self.save() and self.app.overlay_server.server:webbrowser.open(f'http://127.0.0.1:{self.app.overlay_server.port}/alert-preview?event={self.key}')
 def copy(self):
  if self.app.overlay_server.server:self.app.clipboard_clear();self.app.clipboard_append(f'http://127.0.0.1:{self.app.overlay_server.port}/alerts');self.status.set('URL copiada · OBS, fuente Navegador 800 × 500. Pruebas no salen en directo.')
