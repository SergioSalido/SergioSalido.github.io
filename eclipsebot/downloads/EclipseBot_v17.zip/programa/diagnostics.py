import tkinter as tk
from tkinter import ttk, messagebox
import threading
from core import SCOPE

def settings_window(a):
    w=tk.Toplevel(a); w.title('EclipseBot | Ajustes y conexiones'); w.geometry('740x480')
    f=ttk.Frame(w,padding=14); f.pack(fill='both',expand=True)
    report=tk.StringVar(); twitch=tk.StringVar();
    def local():
        from pathlib import Path
        MODEL=Path(__file__).parent/'models'/'vosk-model-small-es-0.42'
        report.set('Micrófono: '+(a.device.get() or 'sin seleccionar')+'\nEscucha: '+('en ejecución / iniciando' if a.audio_busy and not a.audio_stop.is_set() else 'detenida')+'\nModelo Vosk: '+('carpeta encontrada' if MODEL.is_dir() else 'no instalado')+'\nDiscord: '+('atajos habilitados (estado estimado)' if a.panel.enabled else 'atajos deshabilitados')+'\nTikTok: '+(a.ttaccount.get()+' · '+a.ttstatus.get() if hasattr(a,'ttaccount') else 'integración experimental')+'\nOBS: no conectado; contador disponible en muertes.txt')
        twitch.set('Twitch: '+('@'+a.twitch.login+' · '+('modo real' if a.live.get() else 'modo prueba') if a.twitch else 'desconectado'))
    def check():
        local()
        if not a.twitch:return
        if a.busy: twitch.set('Twitch ocupado; vuelve a comprobar.');return
        a.busy=True; obj=a.twitch; twitch.set('Validando sesión…')
        def done(result):
            if w.winfo_exists():twitch.set(result)
        def worker():
            try:
                obj.maintain(); obj.validate(); result='Twitch: sesión y permisos OAuth válidos · @'+obj.login+'\n'+('Cuenta propietaria: encuestas y predicciones habilitables.' if obj.sender==obj.broadcaster else 'Cuenta distinta: encuestas y predicciones requieren la cuenta propietaria.')
            except Exception as e:result='Error al verificar Twitch: '+str(e)
            a.events.put(('diagnostic',(obj,done,result)))
        threading.Thread(target=worker,daemon=True).start()
    ttk.Label(f,text='CONEXIONES Y DIAGNÓSTICO',font=('Segoe UI',16,'bold')).pack(anchor='w')
    ttk.Label(f,textvariable=twitch,wraplength=680).pack(anchor='w',pady=8)
    ttk.Label(f,textvariable=report,wraplength=680).pack(anchor='w',pady=8)
    row=ttk.Frame(f);row.pack(fill='x')
    for label,fn in [('Verificar conexiones',check),('Conectar Twitch',a.connect),('Desconectar',a.disconnect)]:ttk.Button(row,text=label,command=fn).pack(side='left',padx=3)
    ttk.Separator(f).pack(fill='x',pady=12)
    ttk.Label(f,text='AJUSTES GENERALES',font=('Segoe UI',12,'bold')).pack(anchor='w')
    row=ttk.Frame(f);row.pack(fill='x',pady=5)
    for label,fn in [('Enlaces y atajos Discord',a.panel.settings),('Iconos y botones',lambda:__import__('extras').editor(a.panel)),('Historial',a.panel.history)]:ttk.Button(row,text=label,command=fn).pack(side='left',padx=3)
    row=ttk.Frame(f);row.pack(fill='x',pady=5)
    ttk.Label(row,text='Antispam (segundos)').pack(side='left');ttk.Entry(row,textvariable=a.seconds,width=8).pack(side='left',padx=6);ttk.Button(row,text='Guardar ajustes',command=a.save_settings).pack(side='left')
    ttk.Label(f,text='La comprobación no publica mensajes ni cambia el estado de Discord. Los servicios externos requieren autorización y pruebas reales.',wraplength=680).pack(anchor='w',pady=8)
    local()
