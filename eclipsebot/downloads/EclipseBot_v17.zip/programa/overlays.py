"""Loopback-only browser overlays. Demo endpoints never feed production data."""
import json, threading, time, webbrowser, re, uuid, html as html_escape
from tkinter import colorchooser, simpledialog, messagebox
from visual import Banner
from alerts import Alerts
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
import tkinter as tk
from tkinter import ttk
from tkinter import font as tkfont
from PIL import Image, ImageTk
from user_data import DATA_DIR

BASE=DATA_DIR
WIDGETS={
 'likes':('Likes de TikTok','TikTok LIVE',5200,'LIKES RECIBIDOS','heart','#27e9df'),
 'follow-twitch':('Último seguidor · Twitch','Twitch','EspectadorDemo','ÚLTIMO SEGUIDOR','user','#ad83ff'),
 'follow-tiktok':('Último seguidor · TikTok','TikTok','LunaLive','ÚLTIMO SEGUIDOR','user','#27e9df'),
 'deaths':('Contador de muertes','Gameplay',7,'CONTADOR DE MUERTES','skull','#ff455c'),
 'viewers':('Espectadores de TikTok','TikTok LIVE',24,'ESPECTADORES','eye','#27e9df'),
 'gifts':('Regalos de TikTok','TikTok LIVE',18,'REGALOS RECIBIDOS','gift','#ff5e9a'),
}
THEMES={'red':'#ff3c50','purple':'#ad79ff','cyan':'#26e9df','orange':'#ff8b3d'}
ICONS={
 'heart':'<path d="M24 42 6 24C-5 12 10 0 24 14 38 0 53 12 42 24Z"/>',
 'user':'<circle cx="20" cy="15" r="8"/><path d="M5 40v-4c0-9 7-13 15-13 6 0 11 2 13 6M38 20v14m-7-7h14"/>',
 'skull':'<path d="M8 29C-1 4 48-1 43 29l-6 6v8H13v-8Z"/><circle cx="17" cy="24" r="4"/><circle cx="33" cy="24" r="4"/><path d="m25 29-3 5h6Zm-6 9v5m11-5v5"/>',
 'eye':'<path d="M3 24s8-14 21-14 21 14 21 14-8 14-21 14S3 24 3 24Z"/><circle cx="24" cy="24" r="6"/>',
 'gift':'<rect x="6" y="21" width="36" height="23" rx="2"/><rect x="3" y="13" width="42" height="8" rx="2"/><path d="M24 13v31M24 13C5 13 7-2 17 5l7 8Zm0 0C43 13 41-2 31 5l-7 8Z"/>'}

def clean_settings(value):
    def color(name):
        v=value.get(name,'');return v if isinstance(v,str) and re.fullmatch(r'#[0-9a-fA-F]{6}',v) else ''
    def text(name,limit):
        v=value.get(name,'');return str(v or '').strip()[:limit]
    try:scale=max(60,min(140,int(value.get('scale',100))))
    except (ValueError,TypeError):scale=100
    return {'theme':value.get('theme') if value.get('theme') in ('auto',*THEMES) else 'auto','animation':bool(value.get('animation',True)), 'layout':value.get('layout') if value.get('layout') in ('eclipse','minimal','compact') else 'eclipse','label':text('label',60),'footer':text('footer',40),'show_footer':bool(value.get('show_footer',True)),'accent':color('accent'),'text_color':color('text_color'),'scale':scale}

class OverlayServer:
    def __init__(self,port=8765):
        self.alerts=Alerts();self.lock=threading.Lock();self.custom={};self.widgets=dict(WIDGETS);self.data={k:None for k in WIDGETS};self.theme='red';self.settings={};self.server=None;self.port=port
        try:
            raw_custom=json.loads((BASE/'custom_overlays.json').read_text(encoding='utf8'))
            for key, item in raw_custom.items():
                if re.fullmatch(r'custom-[0-9a-f]{12}',key) and isinstance(item,dict):
                    self._register(key,item)
        except (OSError,ValueError,AttributeError,TypeError):pass
        try:
            raw=json.loads((BASE/'overlay_settings.json').read_text(encoding='utf8'))
            self.settings={k:clean_settings(v) for k,v in raw.items() if k in self.widgets and isinstance(v,dict)}
        except (OSError,ValueError,AttributeError):pass
    def _register(self,key,item):
        source=item.get('source','text');name=str(item.get('name','Overlay')).strip()[:60] or 'Overlay';text=str(item.get('text',''))[:120]
        if source not in (*WIDGETS,'text'):return
        self.custom[key]={'name':name,'source':source,'text':text}
        self.widgets[key]=(name,'Personalizado',text or 'Tu texto',name.upper(),'user','#ad83ff') if source=='text' else (name,*WIDGETS[source][1:])
    def _save_custom(self):
        (BASE/'custom_overlays.json').write_text(json.dumps(self.custom,ensure_ascii=False,indent=2),encoding='utf8')
    def create(self,name,source='text',text=''):
        if source not in (*WIDGETS,'text'):raise ValueError('Fuente no válida')
        if not str(name).strip():raise ValueError('Escribe un nombre')
        key='custom-'+uuid.uuid4().hex[:12]
        with self.lock:
            self._register(key,{'name':name,'source':source,'text':text})
            self._save_custom()
        return key
    def edit_custom(self,key,name,text):
        with self.lock:
            item=self.custom[key];self._register(key,{**item,'name':name,'text':text});self._save_custom()
    def delete_custom(self,key):
        with self.lock:
            if key not in self.custom:return
            del self.custom[key];del self.widgets[key];self.settings.pop(key,None);self._save_custom()
            (BASE/'overlay_settings.json').write_text(json.dumps(self.settings,indent=2),encoding='utf8')
    def publish(self,values,theme):
        with self.lock:self.data.update(values);self.theme=theme if theme in THEMES else 'red'
    def configure(self,key,theme,animation,**options):
        with self.lock:
            self.settings[key]=clean_settings({'theme':theme,'animation':animation,**options});data=dict(self.settings)
        (BASE/'overlay_settings.json').write_text(json.dumps(data,indent=2),encoding='utf8')
    def snapshot(self,key,demo=False):
        with self.lock:
            cfg=clean_settings(self.settings.get(key,{}));theme=self.theme if cfg['theme']=='auto' else cfg['theme'];item=self.custom.get(key);source=item['source'] if item else key;v=self.widgets[key][2] if demo else (item['text'] if source=='text' else self.data.get(source))
            return {**cfg,'value':v,'accent':cfg['accent'] or THEMES.get(theme,THEMES['red']),'label':cfg['label'] or self.widgets[key][3],'footer':cfg['footer'] or 'ECLIPSEBOT','text_color':cfg['text_color'] or '#f6f5f8'}
    def url(self,key,demo=False):return f'http://127.0.0.1:{self.port}/'+('preview/' if demo else 'overlay/')+key
    def start(self):
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                path=urlsplit(self.path).path.strip('/').split('/')
                if len(path)==2 and path[0] in ('overlay','preview','data','sample') and path[1] in owner.widgets:
                    kind,key=path
                    if kind in ('data','sample'):body=json.dumps(owner.snapshot(key,kind=='sample'),ensure_ascii=False).encode();ctype='application/json; charset=utf-8'
                    else:body=html(key,kind=='preview',owner.widgets).encode();ctype='text/html; charset=utf-8'
                    self.send_response(200);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
                else:
                    result=owner.alerts.route(path,urlsplit(self.path).query)
                    if not result:self.send_error(404);return
                    body,ctype=result;self.send_response(200);self.send_header("Content-Type",ctype);self.send_header("Content-Length",str(len(body)));self.send_header("Cache-Control","no-store");self.send_header("X-Content-Type-Options","nosniff");self.end_headers();self.wfile.write(body)
        self.server=ThreadingHTTPServer(('127.0.0.1',self.port),Handler);self.port=self.server.server_address[1];threading.Thread(target=self.server.serve_forever,daemon=True).start()
    def close(self):
        if self.server:self.server.shutdown();self.server.server_close();self.server=None

def html(key,demo,widgets=None):
    title,platform,_,label,icon,color=(widgets or WIDGETS)[key]
    title,label,platform=map(html_escape.escape,(title,label,platform))
    endpoint=('/sample/' if demo else '/data/')+key
    return '''<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'''+title+'''</title><style>
    *{box-sizing:border-box} :root{--accent:#ff3c50;--signal:'''+color+'''} html,body{margin:0;background:transparent;overflow:hidden;width:100%;height:100%;font-family:"Segoe UI",Arial,sans-serif} body{display:flex;align-items:center;justify-content:center;padding:18px}
    .outer{position:relative;width:100%;height:100%;max-height:164px;filter:drop-shadow(0 0 7px color-mix(in srgb,var(--accent) 30%,transparent));}
    .frame{position:absolute;inset:0;padding:2px;background:linear-gradient(125deg,#bfc5cf 0%,#343741 21%,var(--accent) 43%,#262630 68%,var(--accent) 100%);clip-path:polygon(0 18%,5% 0,95% 0,100% 18%,100% 80%,95% 100%,5% 100%,0 82%)}
    .inner{width:100%;height:100%;position:relative;display:flex;align-items:center;gap:17px;padding:14px 23px;background:radial-gradient(ellipse at 9% 50%,color-mix(in srgb,var(--accent) 19%,#0a0a10),transparent 52%),repeating-linear-gradient(125deg,#181920 0px,#181920 2px,#111218 2px,#111218 5px);clip-path:polygon(0 18%,5% 0,95% 0,100% 18%,100% 80%,95% 100%,5% 100%,0 82%)}
    .rail{position:absolute;left:8%;right:8%;height:2px;bottom:8px;background:linear-gradient(90deg,transparent,var(--accent) 18%,var(--accent) 61%,transparent);box-shadow:0 0 12px var(--accent)}
    .symbol{flex:none;width:82px;height:82px;border-radius:50%;border:1px solid var(--accent);display:grid;place-items:center;background:radial-gradient(circle,#262732,#101017 65%);box-shadow:inset 0 0 16px #000,0 0 13px color-mix(in srgb,var(--accent) 28%,transparent);position:relative}.symbol:after{content:"";position:absolute;inset:-5px;border:2px solid transparent;border-top-color:var(--accent);border-right-color:var(--accent);border-radius:50%;transform:rotate(-25deg)} svg{width:46px;height:46px;stroke:var(--signal);stroke-width:3;fill:none;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 0 5px color-mix(in srgb,var(--signal) 40%,transparent))}
    .content{min-width:0;flex:1;align-self:center}.top{display:flex;align-items:center;justify-content:space-between;gap:9px;margin-bottom:3px}.label{font-size:12px;font-weight:900;font-style:italic;letter-spacing:1.3px;color:#e6e5eb;white-space:nowrap}.tag{font-size:9px;letter-spacing:1px;font-weight:800;color:var(--signal);white-space:nowrap}.value{font-size:48px;line-height:1.05;font-weight:900;font-style:italic;letter-spacing:-1.8px;color:#f6f5f8;text-shadow:0 4px 10px #000;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name .value{font-size:35px;letter-spacing:-.6px}.sub{color:#a7a6b6;font-size:10px;letter-spacing:2px;font-weight:700;margin-top:5px;display:flex;align-items:center;gap:9px}.dot{height:5px;width:5px;background:var(--accent);box-shadow:0 0 7px var(--accent);border-radius:50%}.stripes{position:absolute;right:21px;bottom:11px;color:var(--accent);font-size:12px;font-weight:900;letter-spacing:2px;font-style:italic}.flash{animation:flash .55s ease-out}@keyframes flash{0%{transform:scale(.97);filter:brightness(1.7)}100%{transform:scale(1);filter:brightness(1)}}
    .value{color:var(--text,#f6f5f8);font-size:calc(48px * var(--size,1))}.name .value{font-size:calc(35px * var(--size,1))}.minimal .frame,.minimal .inner{clip-path:none;border-radius:14px}.minimal .frame{background:var(--accent)}.minimal .inner{background:#111219}.minimal .rail,.minimal .stripes,.minimal .symbol:after{display:none}.compact .outer{max-height:110px}.compact .symbol{width:54px;height:54px}.compact svg{width:32px;height:32px}.compact .inner{gap:12px;padding:8px 16px}.compact .value{font-size:calc(34px * var(--size,1))}.compact .name .value{font-size:calc(25px * var(--size,1))}.compact .sub{display:none}.compact .rail{bottom:4px}.label{overflow:hidden;text-overflow:ellipsis}.sub span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    @media(max-width:340px){.inner{gap:10px;padding:12px 15px}.symbol{width:52px;height:52px}svg{width:30px;height:30px}.value{font-size:33px}.name .value{font-size:24px}.label{font-size:9px}.tag{font-size:8px}.sub{font-size:8px}}
    </style><body><div class="outer '''+('name' if key.startswith(('follow-','custom-')) else '')+'''"><div class="frame"><div class="inner"><div class="symbol"><svg viewBox="0 0 48 48" aria-hidden="true">'''+ICONS[icon]+'''</svg></div><div class="content"><div class="top"><div class="label">'''+label+'''</div><div class="tag">'''+platform.upper()+'''</div></div><div class="value" id="value">—</div><div class="sub"><span class="dot"></span><span id="footer">ECLIPSEBOT</span> <span id="status">'''+('· DEMO' if demo else '')+'''</span></div></div><div class="rail"></div><div class="stripes">///</div></div></div></div><script>
    const value=document.getElementById('value');let previous=null;const endpoint='''+json.dumps(endpoint)+''';async function update(){try{let res=await fetch(endpoint,{cache:'no-store'});if(!res.ok)throw Error('offline');let d=await res.json();document.documentElement.style.setProperty('--accent',d.accent);document.documentElement.style.setProperty('--text',d.text_color);document.documentElement.style.setProperty('--size',d.scale/100);document.body.className=d.layout;document.querySelector('.label').textContent=d.label;document.getElementById('footer').textContent=d.footer;document.querySelector('.sub').style.display=d.show_footer&&d.layout!=='compact'?'flex':'none';let text=d.value==null?'—':typeof d.value==='number'?new Intl.NumberFormat('es-ES',{minimumGroupingDigits:1}).format(d.value):String(d.value);if(text!==previous){value.textContent=text;if(previous!==null&&d.animation){value.classList.remove('flash');void value.offsetWidth;value.classList.add('flash')}previous=text;} }catch(e){value.textContent='—';previous=null;}finally{setTimeout(update,1000)}}update();</script></body></html>'''

class Gallery:
    """Master/detail editor. Changes are previewed locally and saved per widget."""
    def __init__(self,app,p):
        self.app=app;self.server=app.overlay_server;self.selected=tk.StringVar(value='likes');self.theme=tk.StringVar(value='auto');self.anim=tk.BooleanVar(value=True);self.layout=tk.StringVar(value='eclipse');self.label=tk.StringVar();self.footer=tk.StringVar();self.show_footer=tk.BooleanVar(value=True);self.accent=tk.StringVar();self.text_color=tk.StringVar();self.scale=tk.IntVar(value=100);self.loading=False;self.drafts={};self.current=None
        app.head(p,'Overlays','Estudio de diseño · selecciona, personaliza y añade a tu directo.')
        self.status=tk.StringVar(value='Servidor local listo' if self.server.server else 'Servidor local no disponible (puerto ocupado)');app.label(p,var=self.status,color='#b2a4ac',size=10).pack(anchor='w',pady=(0,5))
        shell=tk.Frame(p,bg=p.cget('bg'));shell.pack(fill='both',expand=True);left=tk.Frame(shell,bg='#211318',width=210,padx=8,pady=8,highlightbackground='#59303a',highlightthickness=1);left.pack(side='left',fill='y',padx=(0,8));left.pack_propagate(False);Banner(left,'BIBLIOTECA').pack(fill='x');self.nav={}
        app.btn(left,'＋ Crear overlay',self.create_dialog,True).pack(fill='x',pady=6)
        app.btn(left,'Editar personalizado',self.edit_dialog).pack(fill='x',pady=2)
        app.btn(left,'Eliminar personalizado',self.delete_dialog).pack(fill='x',pady=2)
        listbox=tk.Frame(left,bg=left.cget('bg'));listbox.pack(fill='both',expand=True)
        self.library=tk.Canvas(listbox,bg=left.cget('bg'),highlightthickness=0);scroll=ttk.Scrollbar(listbox,command=self.library.yview);scroll.pack(side='right',fill='y');self.library.pack(side='left',fill='both',expand=True);self.library.configure(yscrollcommand=scroll.set)
        self.library_body=tk.Frame(self.library,bg=left.cget('bg'));winlib=self.library.create_window((0,0),window=self.library_body,anchor='nw');self.library_body.bind('<Configure>',lambda e:self.library.configure(scrollregion=self.library.bbox('all')));self.library.bind('<Configure>',lambda e:self.library.itemconfigure(winlib,width=e.width));self.refresh_library()
        right=tk.Frame(shell,bg=p.cget('bg'));right.pack(side='left',fill='both',expand=True)
        actions=tk.Frame(right,bg='#211318',padx=8,pady=6,highlightbackground='#59303a',highlightthickness=1);actions.pack(side='bottom',fill='x',pady=(6,0));app.btn(actions,'Guardar',self.save,True).pack(side='left',padx=3);app.btn(actions,'Copiar URL',self.copy).pack(side='left',padx=3);app.btn(actions,'Prueba animada',self.preview).pack(side='left',padx=3)
        # Scrollable editor keeps every option reachable on small displays.
        cv=tk.Canvas(right,bg=p.cget('bg'),highlightthickness=0);sb=ttk.Scrollbar(right,orient='vertical',command=cv.yview);cv.configure(yscrollcommand=sb.set);sb.pack(side='right',fill='y');cv.pack(side='left',fill='both',expand=True);body=tk.Frame(cv,bg=p.cget('bg'));win=cv.create_window((0,0),window=body,anchor='nw');body.bind('<Configure>',lambda e:cv.configure(scrollregion=cv.bbox('all')));cv.bind('<Configure>',lambda e:cv.itemconfigure(win,width=e.width));self.body=body
        self.name=tk.StringVar();preview=app.card(body,'Vista previa · datos de ejemplo');app.label(preview,var=self.name,bold=True).pack(anchor='w');self.canvas=tk.Canvas(preview,height=165,bg='#101218',highlightthickness=0);self.canvas.pack(fill='x',pady=4);self.canvas.bind('<Configure>',lambda e:self.draw());app.label(preview,'Vista gráfica orientativa · prueba en navegador para ver el HTML y las animaciones reales.',9,'#b2a4ac').pack(anchor='w')
        f=app.card(body,'Diseño y contenido');
        r=app.row(f);app.label(r,'Estilo',10).pack(side='left');ttk.Combobox(r,textvariable=self.layout,values=['eclipse','minimal','compact'],state='readonly',width=12).pack(side='left',padx=7);app.label(r,'Tema',10).pack(side='left');ttk.Combobox(r,textvariable=self.theme,values=['auto','red','purple','cyan','orange'],state='readonly',width=10).pack(side='left',padx=7)
        app.field(f,'Título (vacío = original)',self.label);app.field(f,'Firma (vacío = EclipseBot)',self.footer);r=app.row(f);app.btn(r,'Usar mi nombre de perfil',lambda:self.footer.set(self.app.display_name.get())).pack(side='left')
        r=app.row(f);ttk.Checkbutton(r,text='Mostrar firma',variable=self.show_footer).pack(side='left');ttk.Checkbutton(r,text='Animar cambios',variable=self.anim).pack(side='left',padx=10)
        r=app.row(f);app.label(r,'Tamaño del valor',10).pack(side='left');tk.Scale(r,from_=60,to=140,orient='horizontal',variable=self.scale,bg=f.cget('bg'),fg='#f2e9ed',highlightthickness=0,length=160).pack(side='left',fill='x',expand=True,padx=8)
        r=app.row(f);app.btn(r,'Color de acento',lambda:self.pick(self.accent)).pack(side='left');app.btn(r,'Color del texto',lambda:self.pick(self.text_color)).pack(side='left',padx=5);app.btn(r,'Restaurar colores',lambda:(self.accent.set(''),self.text_color.set(''))).pack(side='left')
        f=app.card(body,'Publicar en OBS');app.label(f,'Fuente navegador · 500 × 180 px · fondo transparente.',10).pack(anchor='w');self.link=tk.StringVar();e=ttk.Entry(f,textvariable=self.link,state='readonly');e.pack(fill='x',pady=5);app.btn(f,'Restaurar diseño',self.reset).pack(anchor='w',pady=3)
        for var in (self.theme,self.anim,self.layout,self.label,self.footer,self.show_footer,self.accent,self.text_color,self.scale):var.trace_add('write',lambda *_:self.changed())
        self.select('deaths')
        def wheel(e):
            if isinstance(e.widget,(ttk.Combobox,tk.Scale)):return
            cv.yview_scroll((-1 if e.delta>0 else 1)*3,'units');return 'break'
        def bind_tree(widget):
            widget.bind('<MouseWheel>',wheel,add='+')
            for child in widget.winfo_children():bind_tree(child)
        bind_tree(body);cv.bind('<MouseWheel>',wheel)
    def refresh_library(self):
        for w in self.library_body.winfo_children():w.destroy()
        self.nav={}
        for key,(title,*_) in self.server.widgets.items():
            platform=self.server.widgets[key][1]
            unavailable=platform.casefold().startswith('tiktok')
            label=(('＋ ' if key in self.server.custom else '')+title+(' · PRÓXIMAMENTE' if unavailable else ''))
            b=self.app.btn(self.library_body,label,lambda k=key:self.select(k));b.configure(anchor='w',wraplength=145,justify='left');palette=getattr(self.app,'_palette',None)
            if palette:b.configure(bg=palette[2],fg=palette[3],activebackground=palette[4],highlightbackground=palette[2])
            if unavailable:
                b.configure(state='disabled',bg='#28292e',fg='#85878d',disabledforeground='#85878d',activebackground='#28292e',highlightbackground='#45464b',cursor='arrow',font=tkfont.Font(root=self.app,family='Segoe UI',size=9,weight='bold',slant='italic',overstrike=1))
                b.bind('<Enter>',lambda e,button=b:button.configure(highlightbackground='#777980'))
                b.bind('<Leave>',lambda e,button=b:button.configure(highlightbackground='#45464b'))
            b.pack(fill='x',pady=3);self.nav[key]=b
    def create_dialog(self):self.custom_dialog()
    def edit_dialog(self):
        if self.current not in self.server.custom:messagebox.showinfo('Overlay','Selecciona un overlay personalizado.',parent=self.app);return
        self.custom_dialog(self.current)
    def custom_dialog(self,key=None):
        old=self.server.custom.get(key,{})
        w=tk.Toplevel(self.app);w.title('Editar overlay' if key else 'Crear overlay');w.geometry('540x330');w.transient(self.app);w.grab_set()
        names={'Texto personalizado':'text',**{v[0]:k for k,v in WIDGETS.items() if not v[1].casefold().startswith('tiktok')}}
        name=tk.StringVar(value=old.get('name',''));source=tk.StringVar(value=next((n for n,k in names.items() if k==old.get('source','text')),'Texto personalizado'));text=tk.StringVar(value=old.get('text',''))
        frame=ttk.Frame(w,padding=18);frame.pack(fill='both',expand=True)
        for label,var in [('Nombre en la biblioteca',name)]:ttk.Label(frame,text=label).pack(anchor='w');ttk.Entry(frame,textvariable=var).pack(fill='x',pady=(3,12))
        ttk.Label(frame,text='Fuente de datos (o texto libre)').pack(anchor='w');combo=ttk.Combobox(frame,textvariable=source,values=list(names),state='disabled' if key else 'readonly');combo.pack(fill='x',pady=(3,12))
        ttk.Label(frame,text='Texto que verá el público (solo texto personalizado)').pack(anchor='w');entry=ttk.Entry(frame,textvariable=text);entry.pack(fill='x',pady=(3,12))
        def status(*_):entry.configure(state='normal' if names.get(source.get())=='text' else 'disabled')
        source.trace_add('write',status);status()
        def submit():
            if not name.get().strip():messagebox.showerror('Overlay','Escribe un nombre.',parent=w);return
            try:
                if key:self.server.edit_custom(key,name.get(),text.get());created=key
                else:created=self.server.create(name.get(),names[source.get()],text.get())
            except (OSError,ValueError) as e:messagebox.showerror('Overlay',str(e),parent=w);return
            w.destroy();self.refresh_library();self.select(created)
        ttk.Button(frame,text='Guardar overlay',command=submit).pack(anchor='e',pady=8)
    def delete_dialog(self):
        key=self.current
        if key not in self.server.custom:messagebox.showinfo('Overlay','Los predeterminados no se eliminan.',parent=self.app);return
        if not messagebox.askyesno('Eliminar overlay','¿Eliminar este overlay? Su URL dejará de funcionar.',parent=self.app):return
        try:self.server.delete_custom(key)
        except OSError as e:messagebox.showerror('Overlay',str(e),parent=self.app);return
        self.current=None;self.drafts.pop(key,None);self.refresh_library();self.select('deaths')
    def pick(self,var):
        result=colorchooser.askcolor(color=var.get() or '#ff3448',parent=self.app)[1]
        if result:var.set(result)
    def options(self):
        return clean_settings(dict(theme=self.theme.get(),animation=self.anim.get(),layout=self.layout.get(),label=self.label.get(),footer=self.footer.get(),show_footer=self.show_footer.get(),accent=self.accent.get(),text_color=self.text_color.get(),scale=self.scale.get()))
    def load(self,cfg):
        self.loading=True
        for var,k in [(self.theme,'theme'),(self.anim,'animation'),(self.layout,'layout'),(self.label,'label'),(self.footer,'footer'),(self.show_footer,'show_footer'),(self.accent,'accent'),(self.text_color,'text_color'),(self.scale,'scale')]:var.set(cfg[k])
        self.loading=False;self.draw()
    def select(self,key):
        if self.server.widgets.get(key,('', '',))[1].casefold().startswith('tiktok'):return
        if self.current is not None:self.drafts[self.current]=self.options()
        self.current=key;self.selected.set(key);self.name.set(self.server.widgets[key][0]);self.link.set(self.server.url(key));self.load(self.drafts.get(key,clean_settings(self.server.settings.get(key,{}))))
        for k,b in self.nav.items():b.configure(relief='sunken' if k==key else 'flat',highlightthickness=2 if k==key else 1)
        self.status.set('Editando '+self.server.widgets[key][0]+(' · cambios sin guardar' if self.options()!=clean_settings(self.server.settings.get(key,{})) else ''))
    def changed(self):
        if not self.loading:self.draw();self.status.set('Cambios sin guardar · guarda antes de copiar o probar.')
    def draw(self):
        c=self.canvas;w=c.winfo_width();h=c.winfo_height()
        if w<20:return
        c.delete('all');cfg=self.options();key=self.selected.get();_,platform,value,label,icon,signal=self.server.widgets[key];accent=cfg['accent'] or THEMES.get(self.app.app_theme if cfg['theme']=='auto' else cfg['theme'],'#ff3448');fg=cfg['text_color'] or '#f6f5f8';x=12;y=18 if cfg['layout']!='compact' else 35;bot=h-y
        for xx in range(0,w,20):
            for yy in range(0,h,20):
                if (xx//20+yy//20)%2:c.create_rectangle(xx,yy,xx+20,yy+20,fill='#181a22',outline='')
        if cfg['layout']=='eclipse':c.create_polygon(x,y+15,x+17,y,w-x-17,y,w-x,y+15,w-x,bot-15,w-x-17,bot,x+17,bot,x,bot-15,fill='#17131b',outline=accent,width=2)
        else:c.create_rectangle(x,y,w-x,bot,fill='#17131b',outline=accent,width=2)
        if cfg['layout']=='eclipse':
            c.create_line(x+20,bot-4,w-x-20,bot-4,fill=accent,width=2)
            c.create_line(w-x-44,bot-14,w-x-36,bot-24,fill=accent,width=2);c.create_line(w-x-36,bot-14,w-x-28,bot-24,fill=accent,width=2);c.create_line(w-x-28,bot-14,w-x-20,bot-24,fill=accent,width=2)
        cy=(y+bot)/2;c.create_oval(x+15,cy-27,x+69,cy+27,outline=accent,width=2,fill='#22232d');c.create_text(x+42,cy,text={'heart':'♥','user':'＋','skull':'☠','eye':'◉','gift':'✦'}[icon],fill=signal,font=('Segoe UI Symbol',23,'bold'));tx=x+82
        c.create_text(tx,y+20,text=(cfg['label'] or label)[:48],anchor='w',fill='#dedee6',font=('Segoe UI',10,'bold italic'));c.create_text(tx,cy,text=str(value),anchor='w',fill=fg,font=('Segoe UI',max(12,int(min(34,max(16,(w-100)//max(6,len(str(value)))))*cfg['scale']/100)),'bold italic'))
        if w>340:c.create_text(w-x-15,y+15,text=platform.upper(),anchor='e',fill=signal,font=('Segoe UI',8,'bold'))
        if cfg['show_footer'] and cfg['layout']!='compact':c.create_text(tx,bot-18,text=(cfg['footer'] or 'ECLIPSEBOT')+' · DEMO',anchor='w',fill=accent,font=('Segoe UI',9,'bold'))
    def reset(self):self.load(clean_settings({}));self.changed()
    def save(self):
        try:
            cfg=self.options();self.server.configure(self.selected.get(),cfg.pop('theme'),cfg.pop('animation'),**cfg);self.status.set('Diseño guardado · las fuentes se actualizan automáticamente.');return True
        except OSError:self.status.set('No se pudo guardar el diseño.');return False
    def copy(self):
        if not self.server.server:self.status.set('Servidor local no disponible.');return
        if not self.save():return
        self.app.clipboard_clear();self.app.clipboard_append(self.server.url(self.selected.get()));self.status.set('URL copiada para OBS · datos reales, no simulados.')
    def preview(self):
        if self.server.server and self.save():webbrowser.open(self.server.url(self.selected.get(),True))
