import tkinter as tk
from tkinter import ttk
import json, time
from pathlib import Path
from core import normalize, matches, DEFAULT_MESSAGE
from extras import EXTRA, ICONS, editor, action, Image, ImageTk
from user_data import DATA_DIR

COMMANDS = ['Silencia Discord','Activa Discord','Silencia mi micro','Activa mi micro','Suma una muerte','Resta una muerte','Reinicia contador','Discord','YouTube','Instagram','Twitch','Clip','Mi PC']
DEFAULTS = {'YouTube':'','Instagram':'','Twitch':'','Mi PC':''}

def detect(text, aliases):
    for command in sorted(COMMANDS+EXTRA,key=lambda c:len(normalize(c)),reverse=True):
        if matches(text, aliases if command=='Discord' else command): return command
    return None

class Panel:
    def __init__(self, app):
        self.app=app; self.base=DATA_DIR; self.path=self.base/'panel.json'; self.deaths=0; self.theme="red"; self.colors={}; self.skin=None; self.embedded_skin=None
        self.commands=COMMANDS+EXTRA; self.custom={}; self.buttons={}; self.photos={}; self.values=DEFAULTS.copy(); self.keys={'deafen':'ctrl+alt+shift+f9','mute':'ctrl+alt+shift+f10'}
        try:
            d=json.loads(self.path.read_text(encoding='utf-8')); self.theme=d.get('theme','red'); self.theme=self.theme if self.theme in ('red','purple','cyan','orange') else 'red'; self.colors={k:v for k,v in d.get('colors',{}).items() if k in ('bg','card','fg','accent') and isinstance(v,str) and len(v)==7 and v[0]=='#' and all(c in '0123456789abcdefABCDEF' for c in v[1:])}; self.custom=d.get('custom',{}); self.values.update(d.get('values',{})); self.keys.update(d.get('keys',{})); self.deaths=max(0,int(d.get('deaths',0)))
        except (OSError, ValueError, TypeError): pass
        self.states={'deafen':None,'mute':None}; self.enabled=False; self.window=None; self.tray=None
    def save(self):
        self.path.write_text(json.dumps({'theme':self.theme,'colors':self.colors,'custom':self.custom,'values':self.values,'keys':self.keys,'deaths':self.deaths},ensure_ascii=False,indent=2),encoding='utf-8')
        (self.base/'muertes.txt').write_text(str(self.deaths),encoding='utf-8')
    def set_theme(self,key):
        from skin import THEMES
        if key not in THEMES:return
        self.theme=key;self.colors={};self.save()
        self.refresh_buttons()
    def open(self):
        if self.window and self.window.winfo_exists(): self.window.deiconify(); self.window.lift(); return
        from skin import TouchSkin
        w=self.window=tk.Toplevel(self.app);w.title('EclipseBot 17 | XENEON EDGE');__import__('identity').apply_icon(w);w.geometry('1440x520');w.minsize(900,340);w.configure(bg='#08080a')
        self.count=tk.StringVar(value=f'MUERTES  {self.deaths}');self.skin=TouchSkin(self,w)
    def refresh_buttons(self):
        if self.embedded_skin and self.embedded_skin.root.winfo_exists():self.embedded_skin.draw()
        if self.skin and self.window and self.window.winfo_exists():self.skin.draw()
    def history(self):
        w=tk.Toplevel(self.app); w.title('Historial'); t=tk.Text(w,wrap='word'); t.pack(fill='both',expand=True)
        try: t.insert('1.0',(self.base/'historial.log').read_text(encoding='utf-8')[-30000:])
        except OSError: pass
        t.configure(state='disabled')
    def settings(self,section=None):
        w=tk.Toplevel(self.app);w.title('Comandos y Discord');w.geometry('650x530');w.transient(self.app);__import__('identity').apply_icon(w)
        tabs=ttk.Notebook(w);tabs.pack(fill='both',expand=True,padx=14,pady=14)
        links=ttk.Frame(tabs,padding=16);discord=ttk.Frame(tabs,padding=16);tabs.add(links,text='Enlaces y mensajes');tabs.add(discord,text='Control de Discord');entries={}
        ttk.Label(links,text='Qué se envía cuando dices cada comando.').pack(anchor='w',pady=(0,12))
        for k,v in self.values.items():
            ttk.Label(links,text=k).pack(anchor='w');e=ttk.Entry(links);e.insert(0,v);e.pack(fill='x',pady=(3,12));entries[k]=e
        enabled=tk.BooleanVar(value=self.enabled)
        sync_status=tk.StringVar(value='Listo para usar' if all(v is not None for v in self.states.values()) else 'Sin sincronizar')
        ttk.Label(discord,text='Configura estos atajos en Discord → Ajustes de usuario → Atajos de teclado.',wraplength=560).pack(anchor='w',pady=(0,10))
        for k,label in [('mute','Alternar micrófono'),('deafen','Alternar sonido de la llamada')]:
            ttk.Label(discord,text=label,wraplength=560).pack(anchor='w');e=ttk.Entry(discord);e.insert(0,self.keys[k]);e.pack(fill='x',pady=(3,10));entries[k]=e
        ttk.Checkbutton(discord,text='Activar control de Discord',variable=enabled).pack(anchor='w',pady=8)
        ttk.Label(discord,text='Sincronización: deja el micrófono y el sonido activos en Discord y pulsa el botón. Repite si los cambias manualmente.',wraplength=560).pack(anchor='w',pady=(8,8))
        def sync():
            from tkinter import messagebox
            if messagebox.askokcancel('Sincronizar Discord','Confirma que has activado el micrófono y el sonido de la llamada en Discord.',parent=w):
                self.states={'mute':False,'deafen':False};sync_status.set('Sincronizado (estado estimado)')
        ttk.Button(discord,text='Sincronizar Discord',command=sync).pack(anchor='w',pady=4)
        ttk.Label(discord,textvariable=sync_status).pack(anchor='w',pady=4)
        def save():
            for k,e in entries.items():(self.keys if k in self.keys else self.values)[k]=e.get().strip()
            self.enabled=enabled.get()
            self.save();w.destroy()
        ttk.Button(w,text='Guardar ajustes',command=save).pack(pady=(0,12));tabs.select(discord if section=='discord' else links)
    def hide(self):
        try:
            import pystray
            from PIL import Image, ImageDraw
            import threading
            if not self.tray:
                from identity import themed_icon
                from skin import THEMES
                im=themed_icon(THEMES[getattr(self.app,'app_theme','red')][4],64)
                self.tray=pystray.Icon('EclipseBot',im,'EclipseBot',menu=pystray.Menu(pystray.MenuItem('Abrir',lambda: self.app.events.put(('panel_show',None)),default=True),pystray.MenuItem('Salir',lambda:self.app.events.put(('panel_exit',None)))))
                threading.Thread(target=self.tray.run,daemon=True).start()
            if self.window: self.window.withdraw()
            self.app.withdraw()
        except Exception as e: self.app.log('Bandeja: '+str(e))
    def show(self):
        self.app.deiconify(); self.open()
    def run(self,c,manual=False,force_test=False):
        a=self.app
        if c in COMMANDS[:4]:
            key='deafen' if c.endswith('Discord') else 'mute'; target=c.startswith('Silencia')
            if force_test or not self.enabled: a.log('SIMULACIÓN Discord: '+c); return
            # Global shortcuts are toggles; state is an estimate, not Discord telemetry.
            if self.states[key] is None: a.log('Sincroniza el estado de Discord en Ajustes.'); return
            if self.states[key]==target: a.log('Sin cambio (estado estimado): '+c); return
            if key=='mute' and self.states['deafen']: a.log('Activa Discord antes de cambiar el micrófono.'); return
            try:
                import pyautogui
                pyautogui.hotkey(*self.keys[key].split('+')); self.states[key]=target
                if key=='deafen':
                    if target:self._mute_before_deafen=self.states['mute'];self.states['mute']=True
                    else:self.states['mute']=getattr(self,'_mute_before_deafen',None)
                a.log('Atajo enviado: '+c+' (estado no verificado)')
            except Exception as e: a.log('Error de atajo: '+str(e))
            return
        if c in COMMANDS[4:7]:
            if force_test: a.log('SIMULACIÓN: '+c);return
            self.deaths=max(0,self.deaths+ (1 if c==COMMANDS[4] else -1)) if c!=COMMANDS[6] else 0
            self.save(); a.log(f'{c}: {self.deaths}');
            if self.window and self.window.winfo_exists(): self.count.set(f'MUERTES  {self.deaths}')
            return
        if c=='Twitch' and force_test: a.log('SIMULACIÓN: enlace Twitch');return
        if c=='Twitch':
            link=self.values[c].strip() or ('https://www.twitch.tv/'+a.twitch.login if a.twitch else '')
            if not link: a.log('Configura tu enlace de Twitch o conecta tu cuenta.');return
            a.clipboard_clear(); a.clipboard_append(link); a.log('Enlace Twitch copiado; pega en TikTok manualmente.');return
        if c=='Clip' or c in EXTRA: action(self,c,force_test);return
        msg=a.message.get() if c=='Discord' else self.values.get(c,'')
        if not msg: a.log('Configura el enlace de '+c+' en Ajustes.');return
        a.send_command(c,msg,force_test)
