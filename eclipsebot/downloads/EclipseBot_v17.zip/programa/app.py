import json
import queue
import threading
import time
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from core import CHANNEL, PUBLIC_CLIENT_ID, DEFAULT_MESSAGE, matches, Cooldown
from twitch import Twitch, TwitchError
from panel import Panel, detect
from extras import pick
from tiktok_module import TikTokPanel
from diagnostics import settings_window
from user_data import DATA_DIR

BASE = Path(__file__).resolve().parent
MODEL = BASE / 'models' / 'vosk-model-small-es-0.42'
SETTINGS = DATA_DIR / 'settings.json'


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('EclipseBot 17 | Stream Control')
        self.geometry('780x680'); self.minsize(680, 640)
        self.configure(bg='#16161e')
        style = ttk.Style(self); style.theme_use('clam')
        style.configure('.', background='#16161e', foreground='#ece9f3', fieldbackground='#293041', bordercolor='#464151', font=('Segoe UI', 10))
        style.configure('TButton', background='#34264d', padding=7)
        style.map('TButton', background=[('active', '#543980')])
        style.configure('TEntry', fieldbackground='#293041', foreground='#ffffff', insertcolor='#ffffff')
        style.configure('TCombobox', fieldbackground='#293041', foreground='#ffffff')
        style.map('TCombobox', fieldbackground=[('readonly','#293041')], foreground=[('readonly','#ffffff')])
        self.events = queue.Queue(); self.audio_stop = threading.Event(); self.auth_stop = threading.Event()
        self.twitch = None; self.cooldown = Cooldown(); self.busy = False; self.auth_busy = False; self.audio_busy = False
        self.audio_version = 0; self.device_ids = {}; self.last_maintain = time.monotonic()
        self.client = tk.StringVar(value=PUBLIC_CLIENT_ID); self.aliases = tk.StringVar(value='Discord, discor, dis cord'); self.message = tk.StringVar(value=DEFAULT_MESSAGE)
        self.seconds = tk.StringVar(value='60'); self.device = tk.StringVar(); self.live = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='Desconectado · modo prueba'); self.heard = tk.StringVar(value='Todavía no se ha detectado voz.')
        self.load_settings()
        wrap = ttk.Frame(self, padding=18); wrap.pack(fill='both', expand=True); wrap.columnconfigure(1, weight=1)
        tk.Label(wrap, text='ECLIPSEBOT  /  VOZ → CHAT', bg='#16161e', fg='#c4a1ff', font=('Segoe UI', 19, 'bold')).grid(row=0, column=0, columnspan=3, sticky='w')
        ttk.Label(wrap, text='Canal: cuenta de Twitch autorizada').grid(row=1, column=0, columnspan=3, sticky='w', pady=(0,12))
        for row, label, var in [(2,'Client ID de Twitch',self.client),(5,'Palabras (separadas por coma)',self.aliases),(6,'Mensaje de chat',self.message),(7,'Espera entre envíos (seg.)',self.seconds)]:
            ttk.Label(wrap,text=label).grid(row=row,column=0,sticky='w',pady=5,padx=(0,8)); ttk.Entry(wrap,textvariable=var).grid(row=row,column=1,columnspan=2,sticky='ew',pady=5)
        self.connect_btn=ttk.Button(wrap,text='Conectar Twitch',command=self.connect); self.connect_btn.grid(row=3,column=0,sticky='ew',pady=4)
        ttk.Button(wrap,text='Desconectar',command=self.disconnect).grid(row=3,column=1,sticky='w')
        ttk.Label(wrap,textvariable=self.status,wraplength=690).grid(row=4,column=0,columnspan=3,sticky='w',pady=5)
        ttk.Label(wrap,text='Micrófono').grid(row=8,column=0,sticky='w'); self.devices=ttk.Combobox(wrap,textvariable=self.device,state='readonly'); self.devices.grid(row=8,column=1,sticky='ew'); ttk.Button(wrap,text='Actualizar',command=self.refresh_devices).grid(row=8,column=2,padx=(5,0))
        self.start_btn=ttk.Button(wrap,text='▶ Escuchar micrófono',command=self.start_audio); self.start_btn.grid(row=9,column=0,sticky='ew',pady=8)
        ttk.Button(wrap,text='Detener escucha',command=self.stop_audio).grid(row=9,column=1,sticky='w')
        ttk.Checkbutton(wrap,text='Permitir envíos reales al chat de Twitch',variable=self.live,command=self.toggle_live).grid(row=10,column=0,columnspan=3,sticky='w')
        ttk.Button(wrap,text='Simular «Discord» (sin publicar)',command=lambda:self.trigger('discord',force_test=True)).grid(row=11,column=0,columnspan=2,sticky='w',pady=7)
        ttk.Button(wrap,text='Guardar ajustes',command=self.save_settings).grid(row=11,column=2,sticky='e')
        ttk.Label(wrap,text='Última frase reconocida:').grid(row=12,column=0,columnspan=3,sticky='w')
        ttk.Label(wrap,textvariable=self.heard,wraplength=680).grid(row=13,column=0,columnspan=3,sticky='w',pady=3)
        self.logbox=tk.Text(wrap,height=9,bg='#101019',fg='#d9c9f3',font=('Consolas',10),wrap='word',state='disabled',relief='flat'); self.logbox.grid(row=14,column=0,columnspan=3,sticky='nsew',pady=8); wrap.rowconfigure(14,weight=1)
        ttk.Label(wrap,text='Audio procesado en tu PC. No se graba ni se envía audio a Twitch.',wraplength=680).grid(row=15,column=0,columnspan=3,sticky='w')
        self.panel=Panel(self); ttk.Button(wrap,text='Panel táctil XENEON EDGE',command=self.panel.open).grid(row=16,column=0,columnspan=2,sticky='ew',pady=4); ttk.Button(wrap,text='Ajustes y conexiones',command=lambda:settings_window(self)).grid(row=16,column=2,sticky='ew',pady=4)
        self.tiktok_panel=TikTokPanel(self); ttk.Button(wrap,text='TikTok LIVE · PRÓXIMAMENTE',command=self.tiktok_panel.open,state='disabled').grid(row=17,column=0,columnspan=3,sticky='ew',pady=4)
        self.refresh_devices(); self.log('Listo. Prueba primero sin activar los envíos reales.'); self.after(100,self.poll); self.protocol('WM_DELETE_WINDOW',self.close)

    def log(self, text):
        try:
            if not text.startswith('Código Twitch:'):
                with (DATA_DIR/'historial.log').open('a',encoding='utf-8') as f: f.write(time.strftime('%Y-%m-%d %H:%M:%S')+'  '+text+'\n')
        except OSError: pass
        self.logbox.configure(state='normal'); self.logbox.insert('end',time.strftime('%H:%M:%S')+'  '+text+'\n'); self.logbox.see('end'); self.logbox.configure(state='disabled')

    def load_settings(self):
        try:
            data=json.loads(SETTINGS.read_text(encoding='utf-8'))
            for key,var in [('client',self.client),('aliases',self.aliases),('message',self.message),('seconds',self.seconds)]:
                if key in data and key != 'client': var.set(data[key])
        except (OSError, ValueError, TypeError): pass

    def save_settings(self):
        try:
            SETTINGS.write_text(json.dumps({k:v.get() for k,v in [('client',self.client),('aliases',self.aliases),('message',self.message),('seconds',self.seconds)]},ensure_ascii=False,indent=2),encoding='utf-8'); self.log('Ajustes guardados (sin tokens).')
        except OSError as e: self.log('No se pudieron guardar los ajustes: '+str(e))

    def connect(self):
        if self.auth_busy or self.twitch: return
        if not PUBLIC_CLIENT_ID: messagebox.showinfo('Twitch','La aplicación no tiene Client ID de distribución.'); return
        self.save_settings(); self.live.set(False); self.auth_busy=True; self.auth_stop=threading.Event(); stop=self.auth_stop
        obj=Twitch(PUBLIC_CLIENT_ID); self.status.set('Esperando autorización de Twitch…'); self.connect_btn.configure(state='disabled')
        def work():
            try:
                obj.authorize(lambda url,code:self.events.put(('code',(url,code,stop))),stop); self.events.put(('connected',(obj,stop)))
            except Exception as e: self.events.put(('auth_error',(str(e),stop)))
        threading.Thread(target=work,daemon=True).start()

    def disconnect(self):
        self.auth_stop.set();
        if hasattr(self,'twcode'):self.twcode.set('')
        self.twitch=None; self.live.set(False); self.status.set('Desconectado · modo prueba'); self.log('Twitch desconectado.'); self.connect_btn.configure(state='disabled' if self.auth_busy else 'normal')

    def toggle_live(self):
        if self.live.get():
            if not self.twitch: self.live.set(False); messagebox.showinfo('Twitch','Conecta Twitch primero.'); return
            if not messagebox.askyesno('Activar chat real',f'¿Permitir que @{self.twitch.login} publique mensajes y ejecute las acciones de Twitch que confirmes en el chat de @{self.twitch.login}?'): self.live.set(False); return
            self.status.set(f'Conectado como @{self.twitch.login} · ENVÍO REAL'); self.log('Envío real activado.')
        else:
            self.status.set(f'Conectado como @{self.twitch.login} · modo prueba' if self.twitch else 'Desconectado · modo prueba')

    def refresh_devices(self):
        try:
            import sounddevice as sd
            self.device_ids={f'{i}: {d["name"]}':i for i,d in enumerate(sd.query_devices()) if d['max_input_channels']>0}
            self.devices['values']=list(self.device_ids)
            if self.device.get() not in self.device_ids:
                default=sd.default.device[0]; self.device.set(next((k for k,v in self.device_ids.items() if v==default),next(iter(self.device_ids),'')))
        except Exception as e: self.log('Error de micrófono: '+str(e))

    def start_audio(self):
        if self.audio_busy: return
        if not MODEL.is_dir(): messagebox.showerror('Modelo no instalado','Ejecuta 1_INSTALAR.bat primero.'); return
        if self.device.get() not in self.device_ids: messagebox.showerror('Micrófono','Selecciona un micrófono válido.'); return
        self.audio_stop=threading.Event(); stop=self.audio_stop; device=self.device_ids[self.device.get()]; self.audio_busy=True; self.audio_version+=1; version=self.audio_version
        self.start_btn.configure(state='disabled'); self.log('Cargando modelo de voz…')
        def work():
            try:
                import sounddevice as sd
                from vosk import Model, KaldiRecognizer, SetLogLevel
                SetLogLevel(-1); model=Model(str(MODEL)); sample_rate=int(sd.query_devices(device,'input')['default_samplerate']); rec=KaldiRecognizer(model,sample_rate); audio=queue.Queue(maxsize=32)
                def callback(indata,frames,timing,status):
                    try: audio.put_nowait(bytes(indata))
                    except queue.Full: pass
                if stop.is_set(): return
                with sd.RawInputStream(samplerate=sample_rate,blocksize=max(800,sample_rate//10),device=device,dtype='int16',channels=1,callback=callback):
                    self.events.put(('audio_started',version))
                    while not stop.is_set():
                        try: chunk=audio.get(timeout=.25)
                        except queue.Empty: continue
                        if rec.AcceptWaveform(chunk):
                            phrase=json.loads(rec.Result()).get('text','')
                            if phrase: self.events.put(('phrase',(version,phrase)))
            except Exception as e: self.events.put(('audio_error',(version,str(e))))
            finally: self.events.put(('audio_ended',version))
        threading.Thread(target=work,daemon=True).start()

    def stop_audio(self):
        self.audio_stop.set(); self.audio_version+=1; self.log('Escucha detenida.')

    def trigger(self,text,force_test=False):
        command=detect(text,self.aliases.get())
        if command: self.panel.run(command,force_test=force_test)

    def send_command(self,command,msg,force_test=False):
        try: seconds=int(self.seconds.get()); assert 10<=seconds<=3600
        except (ValueError,AssertionError): self.log('Espera inválida: introduce 10–3600 segundos.'); return
        real=bool(self.live.get() and self.twitch and not force_test); mode=(command,'real' if real else 'test'); remain=self.cooldown.remaining(mode,seconds)
        if remain>0: self.log(f'{command} detectado: espera de seguridad ({remain:.0f} s).'); return
        msg=msg.strip()
        if not msg or len(msg)>500: self.log('El mensaje debe tener entre 1 y 500 caracteres.'); return
        if not real:
            self.cooldown.mark(mode); self.log('SIMULACIÓN (no publicado): '+msg); return
        if self.busy: self.log('Twitch ocupado: se omite este evento.'); return
        self.busy=True; self.cooldown.mark(mode); obj=self.twitch
        def work():
            try: obj.send(msg); self.events.put(('sent',(obj,msg)))
            except Exception as e:self.events.put(('send_error',(obj,str(e))))
        threading.Thread(target=work,daemon=True).start()

    def poll(self):
        for _ in range(100):
            try: kind,data=self.events.get_nowait()
            except queue.Empty: break
            if kind=='diagnostic':
                obj,callback,report=data; self.busy=False
                if obj is self.twitch: callback(report)
            elif kind=='extra_result': self.busy=False; self.log(('TWITCH: ' if data[0] else 'Error Twitch: ')+data[1])
            elif kind=='prediction_pick': pick(self,*data)
            elif kind=='panel_show': self.panel.show()
            elif kind=='panel_exit': self.close(); return
            elif kind=='code':
                url,code,stop=data
                if not stop.is_set():
                    self.log('Código Twitch: '+code+' (si la web lo solicita).');
                    if hasattr(self,'twcode'):self.twcode.set('Código temporal: '+code)
                    webbrowser.open(url)
            elif kind=='connected':
                obj,stop=data; self.auth_busy=False
                if hasattr(self,'twcode'):self.twcode.set('')
                if not stop.is_set(): self.twitch=obj; self.status.set(f'Conectado como @{obj.login} · modo prueba'); self.log('Twitch autorizado. Los envíos siguen desactivados.')
                else: self.connect_btn.configure(state='normal')
            elif kind=='auth_error':
                err,stop=data;
                if hasattr(self,'twcode'):self.twcode.set('')
                self.auth_busy=False; self.connect_btn.configure(state='normal'); self.status.set('Desconectado · modo prueba'); self.log('Twitch: '+err)
            elif kind=='audio_started' and data==self.audio_version: self.log('Micrófono activo. Di Discord y haz una pausa corta.')
            elif kind=='phrase':
                version,phrase=data
                if version==self.audio_version and not self.audio_stop.is_set(): self.heard.set(phrase); self.trigger(phrase)
            elif kind=='audio_error': self.log('Error de audio: '+data[1])
            elif kind=='audio_ended': self.audio_busy=False; self.start_btn.configure(state='normal')
            elif kind=='sent': self.busy=False; self.log(f'PUBLICADO EN TWITCH (@{data[0].login}): '+data[1])
            elif kind=='send_error':
                self.busy=False; self.log('Error de Twitch: '+data[1]); self.live.set(False); self.toggle_live()
            elif kind=='maintained': self.busy=False
            elif kind=='maintain_error':
                self.busy=False
                if self.twitch is data[0]: self.log('Sesión: '+data[1]); self.disconnect()
        if self.twitch and not self.busy and time.monotonic()-self.last_maintain>60:
            self.last_maintain=time.monotonic(); self.busy=True; obj=self.twitch
            def maintain():
                try: obj.maintain(); self.events.put(('maintained',obj))
                except Exception as e:self.events.put(('maintain_error',(obj,str(e))))
            threading.Thread(target=maintain,daemon=True).start()
        self.after(100,self.poll)

    def close(self):
        self.tiktok_panel.listener.stop.set(); self.audio_stop.set(); self.auth_stop.set(); self.twitch=None
        if self.panel.tray: self.panel.tray.stop()
        self.destroy()

if __name__=="__main__":
    from identity import set_app_id
    set_app_id()
    from dashboard import Dashboard
    try:
        Dashboard().mainloop()
    except Exception:
        import traceback
        (DATA_DIR/'error_inicio.log').write_text(traceback.format_exc(),encoding='utf-8')
        try: messagebox.showerror('EclipseBot','No se pudo abrir EclipseBot. Revisa programa/error_inicio.log.')
        except Exception: pass
        raise
