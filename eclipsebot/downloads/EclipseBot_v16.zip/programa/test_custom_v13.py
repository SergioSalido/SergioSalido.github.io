import unittest, tempfile, json, urllib.request
from pathlib import Path
from unittest.mock import patch
from overlays import OverlayServer, html
from identity import themed_icon
class CustomOverlays(unittest.TestCase):
    def test_create_restore_delete(self):
        with tempfile.TemporaryDirectory() as tmp,patch('overlays.BASE',Path(tmp)):
            s=OverlayServer(0);key=s.create('Mi objetivo','text','Próxima parada: 100');live=s.create('Mis likes','likes');s.publish({'likes':42},'red');s.configure(live,'cyan',True,label='Mis likes')
            self.assertEqual(s.snapshot(key)['value'],'Próxima parada: 100');self.assertEqual(s.snapshot(live)['value'],42);self.assertEqual(s.snapshot(live,True)['value'],5200)
            s.edit_custom(key,'Otro nombre','Hola');s2=OverlayServer(0);self.assertEqual(s2.snapshot(key)['value'],'Hola');self.assertEqual(s2.snapshot(live)['label'],'Mis likes');self.assertIsNone(s2.snapshot(live)['value']);s2.delete_custom(key);self.assertNotIn(key,OverlayServer(0).widgets)
    def test_http_and_escape(self):
        with tempfile.TemporaryDirectory() as tmp,patch('overlays.BASE',Path(tmp)):
            s=OverlayServer(0);k=s.create('<script>','text','Mi texto');s.start()
            try:
                with urllib.request.urlopen(s.url(k)) as r:page=r.read().decode();self.assertIn('&lt;script&gt;',page);self.assertNotIn('<title><script>',page)
                with urllib.request.urlopen(s.url(k).replace('/overlay/','/data/')) as r:self.assertEqual(json.load(r)['value'],'Mi texto')
            finally:s.close()
    def test_icon(self):
        a=themed_icon('#ff3448');b=themed_icon('#27d8eb');self.assertNotEqual(a.tobytes(),b.tobytes());self.assertEqual(a.getchannel('A').tobytes(),b.getchannel('A').tobytes())
