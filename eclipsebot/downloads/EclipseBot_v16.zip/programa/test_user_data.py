import json
import tempfile
import unittest
from pathlib import Path

from user_data import initialize_data_directory


class UserDataMigrationTests(unittest.TestCase):
    def test_copies_legacy_settings_and_media_without_removing_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old = root / 'old-program'
            new = root / 'user-data'
            old.mkdir()
            (old / 'ui.json').write_text('{"app_theme":"purple"}', encoding='utf-8')
            (old / 'alert_media').mkdir()
            (old / 'alert_media' / 'sound.wav').write_bytes(b'old-media')

            result = initialize_data_directory(old, new)

            self.assertEqual(result, new)
            self.assertEqual(json.loads((new / 'ui.json').read_text())['app_theme'], 'purple')
            self.assertEqual((new / 'alert_media' / 'sound.wav').read_bytes(), b'old-media')
            self.assertTrue((old / 'ui.json').is_file())

    def test_existing_user_data_wins_on_relaunch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old, new = root / 'old-program', root / 'user-data'
            old.mkdir(); new.mkdir()
            (old / 'settings.json').write_text('{"client":"legacy"}', encoding='utf-8')
            (new / 'settings.json').write_text('{"client":"current"}', encoding='utf-8')

            initialize_data_directory(old, new)

            self.assertEqual(json.loads((new / 'settings.json').read_text())['client'], 'current')


if __name__ == '__main__':
    unittest.main()
