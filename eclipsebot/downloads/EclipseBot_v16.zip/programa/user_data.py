"""Per-user storage and one-time migration of settings from older portable builds."""
from __future__ import annotations

import os
from pathlib import Path
import shutil


APP_DIR = Path(__file__).resolve().parent


def data_directory() -> Path:
    if os.name == 'nt':
        root = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming')
        return root / 'EclipseBot'
    root = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
    return root / 'EclipseBot'


def initialize_data_directory(app_dir: Path = APP_DIR, destination: Path | None = None) -> Path:
    """Create the user data folder and copy legacy files once without deleting them."""
    app_dir = Path(app_dir)
    destination = Path(destination) if destination is not None else data_directory()
    destination.mkdir(parents=True, exist_ok=True)
    legacy_files = (
        'settings.json', 'ui.json', 'panel.json', 'muertes.txt', 'historial.log',
        'alerts.json', 'overlay_settings.json', 'custom_overlays.json',
    )
    legacy_directories = ('alert_media', 'icons')
    for name in legacy_files:
        source, target = app_dir / name, destination / name
        if source.is_file() and not target.exists():
            try:
                shutil.copy2(source, target)
            except OSError:
                # Keep the old portable copy available if migration is blocked.
                pass
    for name in legacy_directories:
        source, target = app_dir / name, destination / name
        if source.is_dir() and not target.exists():
            try:
                shutil.copytree(source, target)
            except OSError:
                pass
    return destination


DATA_DIR = initialize_data_directory()
