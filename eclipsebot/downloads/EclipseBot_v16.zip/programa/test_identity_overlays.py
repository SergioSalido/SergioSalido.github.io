import unittest, tempfile, json
from pathlib import Path
from unittest.mock import patch
from identity import clean_name
from overlays import OverlayServer,clean_settings,html
class ProfileAndOverlays(unittest.TestCase):
    def test_name(self):
        self.assertEqual(clean_name('   Mi   nombre  '),'Mi nombre')
        self.assertEqual(clean_name('  '),'Croonan74')
        self.assertEqual(len(clean_name('x'*80)),32)
    def test_settings_validation(self):
        c=clean_settings({'layout':'invalid','accent':'not a color','scale':300,'text_color':'#AABBCC','label':'hola'})
        self.assertEqual((c['layout'],c['accent'],c['scale'],c['text_color'],c['label']),('eclipse','',140,'#AABBCC','hola'))
    def test_saved_settings_independent(self):
        s=OverlayServer(0)
        with tempfile.TemporaryDirectory() as tmp,patch('overlays.BASE',Path(tmp)):
            s.settings={};s.configure('likes','cyan',False,layout='compact',label='Me gusta',footer='Mi canal',accent='#123456',text_color='#ABCDEF',scale=120,show_footer=False)
            d=s.snapshot('likes',True)
            self.assertEqual((d['layout'],d['label'],d['footer'],d['accent'],d['text_color'],d['scale']),('compact','Me gusta','Mi canal','#123456','#ABCDEF',120))
            self.assertFalse(d['show_footer']);self.assertIsNone(s.snapshot('likes')['value'])
            self.assertEqual(s.snapshot('deaths',True)['layout'],'eclipse')
            self.assertEqual(json.loads((Path(tmp)/'overlay_settings.json').read_text())['likes']['layout'],'compact')
    def test_html_settings(self):
        page=html('likes',False)
        for token in ['d.label','d.footer','d.text_color','d.layout','d.scale','/data/likes','transparent']:
            self.assertIn(token,page)
        self.assertNotIn('/sample/likes',page)
