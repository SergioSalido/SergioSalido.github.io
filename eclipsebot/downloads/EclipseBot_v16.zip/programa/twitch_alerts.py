"""Twitch EventSub WebSocket transport, owner OAuth session."""
import json, threading, queue, time
from collections import deque
import requests
URL='wss://eventsub.wss.twitch.tv/ws?keepalive_timeout_seconds=30'

def convert(kind,e):
    user='Anónimo' if e.get('is_anonymous') else e.get('user_name') or 'Usuario'
    if kind=='channel.follow':return ('tw-follow',user,1)
    if kind=='channel.subscribe' and not e.get('is_gift'):return ('tw-sub',user,1)
    if kind=='channel.subscription.message':return ('tw-resub',user,e.get('cumulative_months',1))
    if kind=='channel.subscription.gift':return ('tw-gift',user,e.get('total',1))
    if kind=='channel.cheer':return ('tw-bits',user,e.get('bits',1))
    if kind=='channel.raid':return ('tw-raid',e.get('from_broadcaster_user_name','Canal'),e.get('viewers',1))

def subscriptions(obj):
    b=obj.broadcaster
    return [('channel.follow','2',{'broadcaster_user_id':b,'moderator_user_id':obj.sender}), *[(k,'1',{'broadcaster_user_id':b}) for k in ('channel.subscribe','channel.subscription.message','channel.subscription.gift','channel.cheer')],('channel.raid','1',{'to_broadcaster_user_id':b})]

class TwitchAlerts:
    def __init__(self):self.stop=threading.Event();self.events=queue.Queue(maxsize=250);self.thread=None
    def emit(self,k,v):
        try:self.events.put_nowait((k,v))
        except queue.Full:pass
    def start(self,obj):
        self.stop.set();self.stop=threading.Event();stop=self.stop
        def run():
            try:import websocket
            except ImportError:self.emit('status','Falta instalar websocket-client');return
            seen=deque(maxlen=500);url=URL;handover=False
            while not stop.is_set():
                ws=None
                try:
                    ws=websocket.create_connection(url,timeout=8);ws.settimeout(2);last=time.monotonic();keepalive=40
                    while not stop.is_set():
                        try:raw=ws.recv()
                        except websocket.WebSocketTimeoutException:
                            if time.monotonic()-last>keepalive:raise OSError('timeout')
                            continue
                        if not raw:raise OSError('closed')
                        last=time.monotonic();d=json.loads(raw);m=d['metadata'];p=d['payload'];kind=m['message_type']
                        if kind=='session_welcome':
                            session=p['session'];keepalive=(session.get('keepalive_timeout_seconds') or 30)+10
                            if not handover:
                                errors=[];accepted=0;obj.maintain()
                                for t,v,c in subscriptions(obj):
                                    if stop.is_set():break
                                    r=requests.post('https://api.twitch.tv/helix/eventsub/subscriptions',headers=obj.headers(),json={'type':t,'version':v,'condition':c,'transport':{'method':'websocket','session_id':session['id']}},timeout=9)
                                    if r.status_code==202:accepted+=1
                                    else:errors.append(f'{t}: {r.status_code}')
                                self.emit('status',f'Twitch alertas: {accepted}/6 eventos autorizados'+(' · '+', '.join(errors) if errors else ''))
                                if not accepted:return
                            handover=False;url=URL
                        elif kind=='notification':
                            mid=m.get('message_id');item=convert(m.get('subscription_type'),p['event'])
                            if item and mid not in seen and not stop.is_set():seen.append(mid);self.emit('alert',item)
                        elif kind=='session_reconnect':
                            new=p['session']['reconnect_url'];replacement=websocket.create_connection(new,timeout=8);replacement.settimeout(2);ws.close();ws=replacement;handover=True;last=time.monotonic()
                        elif kind=='revocation':self.emit('status','Twitch revocó un permiso de alertas')
                except Exception:
                    if not stop.is_set():self.emit('status','Alertas Twitch: reconectando…');stop.wait(5)
                    url=URL;handover=False
                finally:
                    if ws:
                        try:ws.close()
                        except Exception:pass
        self.thread=threading.Thread(target=run,daemon=True);self.thread.start()
