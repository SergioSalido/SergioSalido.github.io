import unittest
from types import SimpleNamespace as N
from tiktok_module import Stats, normalize, event_data, Listener
class TestTikTok(unittest.TestCase):
    def test_username(self):
        self.assertEqual(normalize('@cro on'.replace(' ','')),'croon')
        with self.assertRaises(ValueError): normalize('https://example.com')
    def test_chat(self):
        self.assertEqual(event_data('chat',N(user=N(unique_id='demo'),content='hola')),('chat',('demo','hola')))
    def test_like(self): self.assertEqual(event_data('like',N(count=8)),('like',8))
    def test_gift(self):
        g=N(user=N(unique_id='demo'),gift=N(streakable=True,name='Rosa'),repeat_count=3,repeat_end=0)
        self.assertIsNone(event_data('gift',g)); g.repeat_end=1; self.assertEqual(event_data('gift',g),('gift',('demo','Rosa',3)))
    def test_stats(self):
        s=Stats(); s.apply('like',8); s.apply('like',2); s.apply('follow','demo'); s.apply('gift',('demo','Rosa',3)); s.apply('viewers',5)
        self.assertEqual((s.likes,s.follows,s.gifts,s.viewers),(10,1,3,5))
    def test_queue(self):
        l=Listener(); l.emit('status','demo'); self.assertEqual(l.events.get_nowait(),('status','demo'))
