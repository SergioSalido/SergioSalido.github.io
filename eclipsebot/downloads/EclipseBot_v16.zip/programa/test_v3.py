import unittest
from unittest.mock import patch, Mock
from panel import detect
from twitch import Twitch
class Tests(unittest.TestCase):
    def test_commands(self):
        for c in ('Silencia Discord','Activa Discord','Finaliza encuesta','Finalizar apuesta','Cancela apuesta','Suma una muerte','Mi PC','Clip','YouTube'):
            self.assertEqual(detect(c,'Discord, discor'),c)
    def test_owner_gate(self):
        t=Twitch('demo');t.sender='1';t.broadcaster='2';t.maintain=lambda:None
        with self.assertRaisesRegex(Exception,'propietaria'):t.action('Encuesta',{})
    def test_poll_payload(self):
        t=Twitch('demo');t.sender=t.broadcaster='1';t.token='fake';t.maintain=lambda:None
        with patch('twitch.requests.post') as post:
            post.return_value=Mock(ok=True);post.return_value.json.return_value={'data':[]}
            t.action('Encuesta',{'title':'Pregunta','choices':[{'title':'Sí'},{'title':'No'}],'duration':60})
            self.assertEqual(post.call_args.kwargs['json']['broadcaster_id'],'1')
if __name__=='__main__':unittest.main()
