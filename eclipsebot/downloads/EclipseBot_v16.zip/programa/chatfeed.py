import socket, ssl, threading, queue, re

def parse(line):
    m=re.search(r':([^! ]+)!\S+ PRIVMSG #[^ ]+ :(.*)$',line)
    if not m:return None
    name=m[1]
    if line.startswith('@'):
        tags=dict(x.split('=',1) for x in line.split(' ',1)[0][1:].split(';') if '=' in x)
        name=tags.get('display-name') or name
    return name,m[2]

class TwitchFeed:
    def __init__(self): self.events=queue.Queue(maxsize=2000); self.stop=threading.Event(); self.thread=None
    def emit(self,kind,value):
        try:self.events.put_nowait((kind,value))
        except queue.Full:pass
    def start(self,obj,channel):
        self.stop.set(); stop=threading.Event(); self.stop=stop
        def run():
            while not stop.is_set():
                try:
                    with socket.create_connection(('irc.chat.twitch.tv',6697),timeout=10) as raw:
                        with ssl.create_default_context().wrap_socket(raw,server_hostname='irc.chat.twitch.tv') as s:
                            s.settimeout(1); s.sendall(f'PASS oauth:{obj.token}\r\nNICK {obj.login}\r\nCAP REQ :twitch.tv/tags twitch.tv/commands\r\nJOIN #{channel}\r\n'.encode()); buf=b''
                            while not stop.is_set():
                                try: chunk=s.recv(8192)
                                except socket.timeout:continue
                                if not chunk:break
                                buf+=chunk
                                while b'\r\n' in buf:
                                    line,buf=buf.split(b'\r\n',1); line=line.decode('utf-8','replace')
                                    if line.startswith('PING '):s.sendall(('PONG '+line[5:]+'\r\n').encode())
                                    elif ' 366 ' in line:self.emit('status','Conectado')
                                    elif 'Login authentication failed' in line: self.emit('status','Autorización de chat rechazada');return
                                    elif ' RECONNECT' in line:raise OSError('reconnect')
                                    else:
                                        item=parse(line)
                                        if item and not stop.is_set():self.emit('chat',item)
                except Exception:pass
                if not stop.is_set():self.emit('status','Reconectando…');stop.wait(5)
        self.thread=threading.Thread(target=run,daemon=True);self.thread.start()
