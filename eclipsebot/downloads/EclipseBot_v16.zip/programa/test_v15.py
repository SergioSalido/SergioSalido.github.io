import unittest, tempfile, json, urllib.request
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
from dashboard import Dashboard
from skin import THEMES
from panel import COMMANDS
from overlays import OverlayServer

class V15Tests(unittest.TestCase):
    def test_live_counter_http(self):
        server=OverlayServer(0);server.start();self.addCleanup(server.close)
        url=f'http://127.0.0.1:{server.port}/data/deaths'
        for count in (0,1,2,1,0):
            server.publish({'deaths':count},'red')
            with urllib.request.urlopen(url) as r:self.assertEqual(json.load(r)['value'],count)
        with urllib.request.urlopen(f'http://127.0.0.1:{server.port}/sample/deaths') as r:self.assertEqual(json.load(r)['value'],7)

    def test_gui_buttons_and_counter(self):
        try: probe=tk.Tk();probe.destroy()
        except tk.TclError:self.skipTest('No graphical display')
        with tempfile.TemporaryDirectory() as tmp, patch('dashboard.BASE',Path(tmp)):
            app=Dashboard();self.addCleanup(app.close);app.update_idletasks()
            app.set_app_theme('purple');app.update_idletasks()
            for key,(button,label) in app.theme_buttons.items():
                self.assertEqual(button.cget('bg'),THEMES['purple'][4] if key=='purple' else THEMES['purple'][2])
                self.assertEqual(button.cget('text').startswith('✓'),key=='purple')
            def walk(w):
                for child in w.winfo_children():
                    if getattr(child,'_action_button',False):yield child
                    yield from walk(child)
            for page in ('Inicio','Twitch','TikTok'):
                for b in walk(app.pages[page]):self.assertEqual(b.cget('bg'),THEMES['purple'][2])
            app.set_app_theme('red');self.assertTrue(app.theme_buttons['red'][0].cget('text').startswith('✓'))
            app.panel.path=Path(tmp)/'panel.json';app.panel.base=Path(tmp);app.panel.deaths=0
            for cmd,n in [(COMMANDS[4],1),(COMMANDS[4],2),(COMMANDS[5],1),(COMMANDS[6],0)]:
                app.panel.run(cmd,manual=True);app.update_overlays();self.assertEqual(app.overlay_server.snapshot('deaths')['value'],n)
