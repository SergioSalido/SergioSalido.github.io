import time
import requests
from core import CHANNEL, SCOPE

ID = 'https://id.twitch.tv/oauth2'
API = 'https://api.twitch.tv/helix'


class TwitchError(Exception):
    pass


def checked(response, operation):
    if not response.ok:
        # Do not log request bodies, tokens or authorization codes.
        raise TwitchError(f'{operation}: HTTP {response.status_code}.')
    return response.json()


class Twitch:
    def __init__(self, client_id):
        self.client_id = client_id.strip()
        self.token = None
        self.refresh = None
        self.sender = None
        self.login = None
        self.broadcaster = None
        self.validated = 0
        self.expires_at = 0

    def authorize(self, show_code, stop):
        device = checked(requests.post(ID + '/device', data={'client_id': self.client_id, 'scopes': SCOPE}, timeout=15), 'Solicitar autorización')
        show_code(device['verification_uri'], device['user_code'])
        interval = max(5, int(device.get('interval', 5)))
        deadline = time.monotonic() + int(device['expires_in'])
        while time.monotonic() < deadline and not stop.wait(interval):
            res = requests.post(ID + '/token', data={'client_id': self.client_id, 'scopes': SCOPE, 'device_code': device['device_code'], 'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'}, timeout=15)
            if res.ok:
                self.set_tokens(res.json())
                self.validate()
                data = checked(requests.get(API + '/users', params={'login': CHANNEL}, headers=self.headers(), timeout=15), 'Buscar canal')['data']
                if not data:
                    raise TwitchError('No se encuentra el canal ' + CHANNEL)
                self.broadcaster = data[0]['id']
                return
            error = res.json()
            message = str(error.get('message', '')) + ' ' + str(error.get('error', ''))
            if 'authorization_pending' in message or 'authorization pending' in message.lower():
                continue
            if 'slow_down' in message:
                interval += 5
                continue
            raise TwitchError(f'Autorización rechazada o no válida (HTTP {res.status_code}).')
        raise TwitchError('Autorización cancelada o caducada.')

    def set_tokens(self, data):
        self.token = data['access_token']
        self.refresh = data.get('refresh_token')
        self.expires_at = time.monotonic() + int(data.get('expires_in', 3600))

    def headers(self):
        return {'Authorization': 'Bearer ' + self.token, 'Client-Id': self.client_id}

    def validate(self):
        info = checked(requests.get(ID + '/validate', headers={'Authorization': 'OAuth ' + self.token}, timeout=15), 'Validar sesión')
        if info['client_id'] != self.client_id or not set(SCOPE.split()).issubset(info.get('scopes', [])):
            raise TwitchError('La sesión no tiene el permiso de escritura necesario.')
        self.sender, self.login = info['user_id'], info['login']
        self.validated = time.monotonic()

    def maintain(self):
        if time.monotonic() >= self.expires_at - 120:
            if not self.refresh:
                raise TwitchError('Sesión caducada. Vuelve a conectar Twitch.')
            data = checked(requests.post(ID + '/token', data={'client_id': self.client_id, 'grant_type': 'refresh_token', 'refresh_token': self.refresh}, timeout=15), 'Renovar sesión')
            self.set_tokens(data)
            self.validate()
        elif time.monotonic() - self.validated >= 3500:
            self.validate()

    def send(self, message):
        self.maintain()
        result = checked(requests.post(API + '/chat/messages', headers=self.headers(), json={'broadcaster_id': self.broadcaster, 'sender_id': self.sender, 'message': message}, timeout=15), 'Enviar mensaje')
        item = result['data'][0]
        if not item.get('is_sent'):
            raise TwitchError('Twitch no ha publicado el mensaje: ' + str((item.get('drop_reason') or {}).get('code', 'rechazado')))
        return item['message_id']

    def stream_live(self):
        data=checked(requests.get(API+'/streams',headers=self.headers(),params={'user_id':self.broadcaster},timeout=12),'Estado del directo')['data']
        return bool(data)

    def latest_follower(self):
        data=checked(requests.get(API+'/channels/followers',headers=self.headers(),params={'broadcaster_id':self.broadcaster,'first':1},timeout=12),'Último seguidor')['data']
        return data[0]['user_name'] if data else None

    def current(self, resource):
        self.maintain()
        data=checked(requests.get(API+'/'+resource,headers=self.headers(),params={'broadcaster_id':self.broadcaster,'first':1},timeout=15),'Consultar '+resource)['data']
        return next((x for x in data if x['status'] in (('ACTIVE','LOCKED') if resource=='predictions' else ('ACTIVE',))),None)

    def action(self, command, payload):
        self.maintain()
        if command=='Clip':
            result=checked(requests.post(API+'/clips',headers=self.headers(),params={'broadcaster_id':self.broadcaster},timeout=15),'Crear clip')['data'][0]
            for _ in range(5):
                time.sleep(3)
                clips=checked(requests.get(API+'/clips',headers=self.headers(),params={'id':result['id']},timeout=10),'Verificar clip')['data']
                if clips: return 'Clip creado: '+clips[0]['url']
            return 'Solicitud de clip aceptada, pero aún no confirmada: '+result.get('edit_url','')
        if self.sender!=self.broadcaster: raise TwitchError('Se requiere la cuenta propietaria.')
        resource='polls' if command in ('Encuesta','Finaliza encuesta') else 'predictions'
        body={'broadcaster_id':self.broadcaster,**payload}
        if command in ('Encuesta','Inicia una apuesta'):
            checked(requests.post(API+'/'+resource,headers=self.headers(),json=body,timeout=15),command)
        else:
            if command!='Finalizar apuesta':
                current=self.current(resource)
                if not current: raise TwitchError('No hay evento activo.')
                body['id']=current['id']
            body['status']={'Finalizar apuesta':'RESOLVED','Cancela apuesta':'CANCELED','Finaliza encuesta':'TERMINATED'}[command]
            checked(requests.patch(API+'/'+resource,headers=self.headers(),json=body,timeout=15),command)
        return command+' confirmado por Twitch.'
