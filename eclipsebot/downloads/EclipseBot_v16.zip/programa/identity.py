import os, tkinter as tk
from pathlib import Path
BASE=Path(__file__).resolve().parent

def clean_name(value):
    return ' '.join(str(value or '').split())[:32] or 'Croonan74'

def set_app_id():
    if os.name=='nt':
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('EclipseBot.StreamControl.Desktop')
        except Exception:pass

def apply_dark_titlebar(window):
    """Ask Windows 10/11 to use EclipseBot's black title bar and light caption text."""
    if os.name != 'nt':
        return
    try:
        import ctypes
        window.update_idletasks()
        hwnd = ctypes.c_void_p(window.winfo_id())
        dwm = ctypes.windll.dwmapi
        enabled = ctypes.c_int(1)
        # Windows 11 and recent Windows 10 builds; older builds used attribute 19.
        for attribute in (20, 19):
            try:
                dwm.DwmSetWindowAttribute(hwnd, attribute, ctypes.byref(enabled), ctypes.sizeof(enabled))
            except Exception:
                pass
        black = ctypes.c_int(0x000000)
        white = ctypes.c_int(0xFFFFFF)
        dwm.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(black), ctypes.sizeof(black))
        dwm.DwmSetWindowAttribute(hwnd, 36, ctypes.byref(white), ctypes.sizeof(white))
    except Exception:
        # Keep the app usable if Windows or Tk does not expose DWM customization.
        pass


def apply_icon(window):
    try:
        if os.name=='nt':window.iconbitmap(default=str(BASE/'assets'/'eclipsebot.ico'))
        window._eclipse_icon=tk.PhotoImage(file=str(BASE/'assets'/'eclipsebot.png'))
        window.iconphoto(True,window._eclipse_icon)
    except tk.TclError:pass


def themed_icon(accent='#ff3448',size=64):
    from PIL import Image, ImageColor
    im=Image.open(BASE/'assets'/'eclipsebot.png').convert('RGBA')
    target=ImageColor.getrgb(accent)
    pixels=[]
    for r,g,b,a in im.getdata():
        weight=max(0,min(1,(r-max(g,b))/max(1,r)*1.5))
        brightness=r/255
        pixels.append(tuple(round(c*(1-weight)+t*brightness*weight) for c,t in zip((r,g,b),target))+(a,))
    im.putdata(pixels)
    return im.resize((size,size),Image.Resampling.LANCZOS)

def apply_theme_icon(window,accent):
    from PIL import ImageTk
    window._eclipse_icon=ImageTk.PhotoImage(themed_icon(accent,64),master=window)
    window.iconphoto(True,window._eclipse_icon)
