import os, tkinter as tk
from pathlib import Path
BASE=Path(__file__).resolve().parent

def clean_name(value):
    return ' '.join(str(value or '').split())[:32] or 'Croonan74'

def set_app_id():
    if os.name=='nt':
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('EclipseBot.StreamControl.Desktop')
        except Exception:pass

def apply_dark_titlebar(window):
    """Style the native Windows frame after Tk has mapped its wrapper window."""
    if os.name != 'nt':
        return
    def paint():
        try:
            import ctypes
            from ctypes import wintypes
            if not window.winfo_exists():
                return
            user32 = ctypes.windll.user32
            user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
            user32.GetAncestor.restype = wintypes.HWND
            # winfo_id is Tk's client HWND; DWM needs its outer native frame.
            hwnd = user32.GetAncestor(window.winfo_id(), 2) or window.winfo_id()
            dwm = ctypes.windll.dwmapi
            dwm.DwmSetWindowAttribute.argtypes = (wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD)
            for attribute, value in ((20, 1), (19, 1), (35, 0x000000), (36, 0xFFFFFF)):
                color = ctypes.c_int(value)
                dwm.DwmSetWindowAttribute(hwnd, attribute, ctypes.byref(color), ctypes.sizeof(color))
        except (OSError, AttributeError, tk.TclError):
            pass
    if not getattr(window, '_eclipse_titlebar_bound', False):
        window._eclipse_titlebar_bound = True
        window.bind('<Map>', lambda event: window.after(100, paint) if event.widget == window else None, add='+')
    window.after_idle(paint)


def apply_icon(window):
    apply_dark_titlebar(window)
    try:
        if os.name=='nt':window.iconbitmap(default=str(BASE/'assets'/'eclipsebot.ico'))
        window._eclipse_icon=tk.PhotoImage(file=str(BASE/'assets'/'eclipsebot.png'))
        window.iconphoto(True,window._eclipse_icon)
    except tk.TclError:pass


def themed_icon(accent='#ff3448',size=64):
    from PIL import Image, ImageColor
    im=Image.open(BASE/'assets'/'eclipsebot.png').convert('RGBA')
    target=ImageColor.getrgb(accent)
    pixels=[]
    for r,g,b,a in im.getdata():
        weight=max(0,min(1,(r-max(g,b))/max(1,r)*1.5))
        brightness=r/255
        pixels.append(tuple(round(c*(1-weight)+t*brightness*weight) for c,t in zip((r,g,b),target))+(a,))
    im.putdata(pixels)
    return im.resize((size,size),Image.Resampling.LANCZOS)

def apply_theme_icon(window,accent):
    from PIL import ImageTk
    window._eclipse_icon=ImageTk.PhotoImage(themed_icon(accent,64),master=window)
    window.iconphoto(True,window._eclipse_icon)
