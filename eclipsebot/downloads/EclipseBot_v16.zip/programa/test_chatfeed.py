import unittest
from chatfeed import parse
class TestChat(unittest.TestCase):
    def test_twitch(self):self.assertEqual(parse('@display-name=David :david!david@host PRIVMSG #croonan74 :Hola: Twitch'),('David','Hola: Twitch'))
    def test_ping(self):self.assertIsNone(parse('PING :tmi.twitch.tv'))
    def test_no_tags(self):self.assertEqual(parse(':david!david@host PRIVMSG #croonan74 :Hola'),('david','Hola'))
