import unittest,tempfile
from alerts import Alerts
from twitch_alerts import convert
class AlertTests(unittest.TestCase):
 def test_queue(self):
  with tempfile.TemporaryDirectory() as p:
   a=Alerts(p);a.emit('tw-gift','Ana',3);self.assertEqual(a.snapshot(-1)['events'],[]);self.assertIn('3 subs',a.snapshot(0)['events'][0]['text']);self.assertEqual(a.snapshot(1)['events'],[])
 def test_disabled(self):
  with tempfile.TemporaryDirectory() as p:
   a=Alerts(p);c=a.config('tw-follow');c['enabled']=False;a.save('tw-follow',c);a.emit('tw-follow','Ana');self.assertEqual(a.snapshot(0)['events'],[])
 def test_no_gift_duplicate(self):self.assertIsNone(convert('channel.subscribe',{'is_gift':True}))
 def test_anonymous(self):self.assertEqual(convert('channel.cheer',{'is_anonymous':True,'bits':15}),('tw-bits','Anónimo',15))
 def test_media_path(self):
  with tempfile.TemporaryDirectory() as p:self.assertIsNone(Alerts(p).route(['alert-media','../secret'],''))
 def test_preview_separate(self):
  with tempfile.TemporaryDirectory() as p:
   a=Alerts(p);a.route(['alert-sample','tw-follow'],'');self.assertEqual(a.snapshot(0)['events'],[])
