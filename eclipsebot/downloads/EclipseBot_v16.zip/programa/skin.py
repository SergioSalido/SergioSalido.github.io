"""Native, responsive touch controls. No screenshot hit maps."""
import tkinter as tk
from tkinter import colorchooser, messagebox
from PIL import Image, ImageDraw, ImageTk
from pathlib import Path
from extras import ICONS, editor
from visual import rgb, blend
ASSETS=Path(__file__).parent/'assets'
THEMES={'red':('Eclipse Red','#100b0e','#211318','#f2e9ed','#ff3448'),'purple':('Neon Purple','#120d1b','#231932','#f5efff','#a66aff'),'cyan':('Arctic Cyan','#091519','#12282e','#e8fcff','#27d8eb'),'orange':('Ember Orange','#18100a','#2d2116','#fff1db','#ff922e')}
TILES=['Discord','YouTube','Instagram','Twitch','Clip','Silencia Discord','Activa Discord','Silencia mi micro','Activa mi micro','Mi PC','Encuesta','Finaliza encuesta','Inicia una apuesta','Finalizar apuesta','Cancela apuesta','Suma una muerte','Resta una muerte','Reinicia contador']

def palette(p):
    base=THEMES[p.theme]; custom=getattr(p,'colors',{})
    return tuple([base[0]]+[custom.get(k,v) for k,v in zip(('bg','card','fg','accent'),base[1:])])

def platform_icon(cmd,size):
    if cmd not in ('Discord','YouTube','Instagram','Twitch','Silencia Discord','Activa Discord'):return None
    im=Image.new('RGBA',(100,100));d=ImageDraw.Draw(im)
    if cmd=='YouTube':
        d.rounded_rectangle((7,21,93,79),13,fill='#ff1639');d.polygon([(42,35),(42,65),(67,50)],fill='white')
    elif cmd=='Instagram':
        for j in range(8):
            col=blend((154,55,255),(255,157,42),j/7);d.arc((12,12,88,88),j*45,(j+1)*45,fill=col,width=10)
        d.ellipse((32,32,68,68),outline='#f76aac',width=7);d.ellipse((67,23,77,33),fill='#ffb165')
    elif cmd=='Twitch':
        d.polygon([(14,9),(91,9),(91,63),(67,87),(49,87),(35,100),(35,87),(14,87)],fill='#a76aff');d.polygon([(23,17),(82,17),(82,59),(63,78),(44,78),(36,86),(36,72),(23,72)],fill='#211433');d.rectangle((39,29,47,53),fill='#c49aff');d.rectangle((61,29,69,53),fill='#c49aff')
    else:
        c='#8190fa' if cmd!='Silencia Discord' else '#9c9ba9';d.polygon([(9,70),(15,28),(34,18),(40,26),(60,26),(66,18),(85,28),(91,70),(72,84),(64,73),(36,73),(28,84)],fill=c);d.ellipse((28,40,43,57),fill='#161626');d.ellipse((57,40,72,57),fill='#161626');d.arc((30,41,70,69),10,170,fill='#161626',width=4)
        if cmd=='Silencia Discord':d.line((15,85,85,15),fill='#ff3448',width=10)
        if cmd=='Activa Discord':d.arc((52,11,99,91),-65,65,fill='#34d67e',width=7)
    return im.resize((size,size),Image.Resampling.LANCZOS)

class Tile(tk.Canvas):
    def __init__(self,parent,skin,cmd):
        super().__init__(parent,height=82,width=85,highlightthickness=0,bd=0,takefocus=True,cursor='hand2');self.skin=skin;self.cmd=cmd;self.hover=False;self.down=False;self.flash=False;self.images=[]
        self.bind('<Configure>',lambda e:self.draw());self.bind('<Enter>',lambda e:self.change('hover',True));self.bind('<Leave>',lambda e:self.change('hover',False));self.bind('<ButtonPress-1>',lambda e:self.change('down',True));self.bind('<ButtonRelease-1>',self.release);self.bind('<space>',self.keyboard);self.bind('<Return>',self.keyboard);self.bind('<FocusIn>',lambda e:self.draw());self.bind('<FocusOut>',lambda e:self.draw())
    def change(self,k,v):setattr(self,k,v);self.draw()
    def release(self,e):
        was=self.down;self.down=False
        if was and 0<=e.x<self.winfo_width() and 0<=e.y<self.winfo_height():self.keyboard()
        else:self.draw()
    def keyboard(self,e=None):
        self.flash=True;self.draw();self.after(220,lambda:self.change('flash',False));self.after_idle(lambda:self.skin.execute(self.cmd));return 'break'
    def draw(self):
        w,h=self.winfo_width(),self.winfo_height()
        if w<12 or h<12:return
        _,bg,card,fg,accent=palette(self.skin.p);data=self.skin.p.custom.get(self.cmd,{});card=data.get('color',card)
        try:base=rgb(card)
        except Exception:base=rgb(palette(self.skin.p)[2])
        a=rgb(accent);active=self.down or self.flash;hover=self.hover or self.focus_get()==self
        im=Image.new('RGB',(w,h),bg);d=ImageDraw.Draw(im);r=min(13,w//5,h//5);fill=blend(base,a,.36 if active else .13 if hover else .05)
        d.rounded_rectangle((1,1,w-2,h-2),r,fill=blend(base,a,.5),outline=a if active or hover else blend(base,a,.65),width=2)
        d.rounded_rectangle((3,3,w-4,h-4),max(2,r-2),fill=fill)
        for y in range(10,max(10,h-9)):
            col=blend(fill,(0,0,0),.42*y/h);d.line((5,y,w-6,y),fill=col)
        d.line((r,h-3,w-r,h-3),fill=a,width=2 if not active else 4)
        d.line((r,3,w-r,3),fill=blend(a,(255,255,255),.44),width=1)
        self.images=[ImageTk.PhotoImage(im)];self.delete('all');self.create_image(0,0,image=self.images[0],anchor='nw')
        icon=data.get('symbol',ICONS.get(self.cmd,'◆'));path=data.get('image');offset=2 if active else 0;icon_size=max(14,min(34,int(h*.32)))
        if path:
            try:
                with Image.open(self.skin.p.base/path) as f:f.thumbnail((icon_size*2,icon_size*2));self.images.append(ImageTk.PhotoImage(f.copy()))
                self.create_image(w/2,h*.31+offset,image=self.images[-1]);icon=None
            except (OSError,ValueError):pass
        if icon and not data.get('symbol'):
            custom_icon=platform_icon(self.cmd,int(icon_size*1.65))
            if custom_icon is not None:
                self.images.append(ImageTk.PhotoImage(custom_icon));self.create_image(w/2,h*.30+offset,image=self.images[-1]);icon=None
        if icon:self.create_text(w/2,h*.30+offset,text=icon,fill=accent if active else fg,font=('Segoe UI Emoji',icon_size,'bold'))
        self.create_text(w/2,h*.74+offset,text=data.get('label',self.cmd).upper(),width=max(10,w-10),fill=fg,font=('Segoe UI',max(8,min(12,int(w/12),int(h/8))),'bold italic'),justify='center')
        if active:self.create_rectangle(w-12,5,w-6,11,fill=accent,outline='')

class TouchSkin:
    def __init__(self,p,parent,embedded=False):
        self.p=p;self.app=p.app;self.w=parent;self.embedded=embedded;self.last=None;self.tiles=[];self.brand_image=None
        self.root=tk.Frame(parent,padx=8,pady=6);self.root._touch_scope=True;self.root.pack(fill='both',expand=True)
        self.header=tk.Frame(self.root);self.header.pack(fill='x',pady=(0,6));self.brand=tk.Label(self.header,text='ECLIPSEBOT',font=('Segoe UI',15,'bold italic'));self.brand.pack(side='left');self.status=tk.Label(self.header,font=('Segoe UI',9,'bold'),anchor='e');self.status.pack(side='right',fill='x',expand=True)
        self.body=tk.Frame(self.root);self.body.pack(fill='both',expand=True);self.grid=tk.Frame(self.body);self.grid.pack(side='left',fill='both',expand=True)
        for i,c in enumerate(TILES):
            t=Tile(self.grid,self,c);t.grid(row=i//6,column=i%6,sticky='nsew',padx=3,pady=3);self.tiles.append(t)
        for i in range(6):self.grid.columnconfigure(i,weight=1,uniform='tiles')
        for i in range(3):self.grid.rowconfigure(i,weight=1,uniform='tiles')
        self.side=tk.Frame(self.body,padx=6,pady=5);self.side.pack(side='right',fill='y',padx=(6,0));self.title=tk.Label(self.side,text='MUERTES',font=('Segoe UI',10,'bold italic'));self.title.pack(fill='x');self.counter=tk.Label(self.side,font=('Segoe UI',30,'bold italic'));self.counter.pack(fill='x');r=tk.Frame(self.side);r.pack(fill='x');self.small=[]
        for label,fn,par in [('−',lambda:self.execute('Resta una muerte'),r),('+',lambda:self.execute('Suma una muerte'),r),('Abrir chat',self.app.floating,self.side),('Personalizar',lambda:customize(p,self.root),self.side)]:
            b=self.make_button(par,label,fn);b.pack(side='left' if par is r else 'top',fill='both',expand=par is r,padx=2,pady=3);self.small.append(b)
        self.feedback=tk.Label(self.root,text='Preparado · pulsa cualquier botón',anchor='w',font=('Segoe UI',10));self.feedback.pack(fill='x',pady=(5,0));self.toolbar=tk.Frame(self.root);self.toolbar.pack(fill='x')
        items=[('Editar iconos',lambda:editor(p)),('Enlaces y Discord',p.settings)]
        if embedded:items.insert(0,('Abrir ventana táctil',p.open))
        else:items += [('Historial',p.history),('Bandeja',p.hide),('Pantalla completa',self.fullscreen)]
        for label,fn in items:
            b=self.make_button(self.toolbar,label,fn);b.pack(side='left',padx=3,pady=3);self.small.append(b)
        if not embedded:
            parent.bind('<Escape>',lambda e:parent.attributes('-fullscreen',False));parent.bind('<F11>',lambda e:self.fullscreen())
        self.draw();self.refresh()
    def make_button(self,par,label,fn):return tk.Button(par,text=label,command=fn,cursor='hand2',relief='flat',bd=0,padx=7,pady=6,font=('Segoe UI',10,'bold'))
    def fullscreen(self):self.w.attributes('-fullscreen',not self.w.attributes('-fullscreen'))
    def execute(self,cmd):
        if cmd=='Reinicia contador' and not messagebox.askyesno('Reiniciar','¿Poner el contador a cero?',parent=self.root):return
        self.feedback.configure(text='Acción solicitada: '+cmd+' · consulta Historial para el resultado')
        self.p.run(cmd,manual=True);self.refresh_values()
    def refresh_values(self):
        self.counter.configure(text=f'{self.p.deaths:03d}');tt=getattr(self.app,'ttstatus',None);self.status.configure(text='TWITCH: '+self.app.status.get()+'   |   TIKTOK: '+(tt.get() if tt else 'Desconectado'))
    def refresh(self):
        if not self.root.winfo_exists():return
        self.refresh_values();self.root.after(500,self.refresh)
    def draw(self):
        _,bg,card,fg,accent=palette(self.p)
        def paint(w):
            if isinstance(w,Tile):w.configure(bg=bg);w.draw();return
            if isinstance(w,tk.Button):w.configure(bg=card,fg=fg,activebackground=accent,activeforeground=fg,highlightbackground=accent,highlightthickness=1)
            elif isinstance(w,(tk.Frame,tk.Label)):w.configure(bg=bg,**({'fg':fg} if isinstance(w,tk.Label) else {}))
            for child in w.winfo_children():paint(child)
        paint(self.root);self.side.configure(bg=card,highlightthickness=1,highlightbackground=accent);self.counter.configure(fg=accent);self.title.configure(bg=card,fg=fg);self.counter.configure(bg=card)
        try:
            from identity import themed_icon
            self.brand_image=ImageTk.PhotoImage(themed_icon(accent,36));self.brand.configure(image=self.brand_image,compound='left',text=' ECLIPSEBOT',fg=accent)
        except OSError:pass
        if not self.embedded:self.w.configure(bg=bg)
        self.refresh_values()

def customize(p,parent):
    w=tk.Toplevel(parent);w._touch_scope=True;w.title('Personalización · solo panel táctil');w.geometry('520x410');w.transient(parent.winfo_toplevel())
    name=tk.StringVar(value='');swatches={};buttons=[]
    def refresh():
        title,bg,card,fg,accent=palette(p);name.set('Tema: '+title+(' · personalizado' if p.colors else ''));w.configure(bg=bg);heading.configure(bg=bg,fg=fg);sub.configure(bg=bg,fg=fg);row.configure(bg=bg);colors.configure(bg=bg);bottom.configure(bg=bg)
        for b,key in buttons:b.configure(bg=accent if key==p.theme else card,fg=fg,activebackground=accent,activeforeground=fg)
        for k,(label,b) in swatches.items():
            val=dict(zip(('bg','card','fg','accent'),(bg,card,fg,accent)))[k];label.configure(bg=bg,fg=fg);b.configure(text=val,bg=val,fg='#ffffff' if sum(rgb(val))<400 else '#111111')
        for b in bottom.winfo_children():b.configure(bg=card,fg=fg,activebackground=accent)
    def choose(k):
        val=colorchooser.askcolor(color=dict(zip(('bg','card','fg','accent'),palette(p)[1:]))[k],parent=w)[1]
        if val:p.colors[k]=val;p.save();p.refresh_buttons();refresh()
    heading=tk.Label(w,textvariable=name,font=('Segoe UI',16,'bold italic'));heading.pack(pady=12);sub=tk.Label(w,text='Los cambios no modifican la aplicación ni los overlays.');sub.pack();row=tk.Frame(w);row.pack(fill='x',padx=12,pady=12)
    for k,t in THEMES.items():
        b=tk.Button(row,text=t[0],command=lambda k=k:(p.set_theme(k),refresh()),cursor='hand2');b.pack(side='left',expand=True,fill='x',padx=2);buttons.append((b,k))
    colors=tk.Frame(w);colors.pack(fill='x',padx=18)
    for i,(k,text) in enumerate([('bg','Fondo'),('card','Botones y tarjetas'),('fg','Letras e iconos'),('accent','Bordes e iluminación')]):
        l=tk.Label(colors,text=text,anchor='w');l.grid(row=i,column=0,sticky='ew',pady=5);b=tk.Button(colors,command=lambda k=k:choose(k),width=14);b.grid(row=i,column=1,sticky='e');swatches[k]=(l,b)
    colors.columnconfigure(0,weight=1);bottom=tk.Frame(w);bottom.pack(fill='x',padx=12,pady=12)
    def reset():
        if messagebox.askyesno('Restaurar botones','¿Eliminar las personalizaciones individuales de todos los botones?',parent=w):p.custom.clear();p.save();p.refresh_buttons();refresh()
    for t,fn in [('Restaurar colores',lambda:(p.set_theme(p.theme),refresh())),('Restaurar botones',reset),('Cerrar',w.destroy)]:tk.Button(bottom,text=t,command=fn).pack(side='left',expand=True,padx=2)
    refresh()
