import re
import unicodedata
import time

CHANNEL = 'croonan74'
DISCORD = 'https://discord.gg/sPaDvk25td'
DEFAULT_MESSAGE = '💜 ¡Únete al Discord de Croonan74! ' + DISCORD
SCOPE = 'user:write:chat chat:read clips:edit channel:manage:polls channel:manage:predictions moderator:read:followers channel:read:subscriptions bits:read'


def normalize(text):
    text = unicodedata.normalize('NFKD', text.casefold())
    return ' '.join(re.findall(r'\w+', ''.join(c for c in text if not unicodedata.combining(c))))


def matches(text, aliases):
    phrase = ' ' + normalize(text) + ' '
    return any(' ' + word + ' ' in phrase for alias in aliases.split(',') if (word := normalize(alias)))


class Cooldown:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.last = {}

    def remaining(self, mode, seconds):
        return max(0, seconds - (self.clock() - self.last.get(mode, float('-inf'))))

    def mark(self, mode):
        self.last[mode] = self.clock()
