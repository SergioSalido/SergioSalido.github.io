import unittest, urllib.request, json
from overlays import OverlayServer, WIDGETS
from tiktok_module import Stats
class TestOverlays(unittest.TestCase):
    def test_production_isolation(self):
        server=OverlayServer(0);self.assertIsNone(server.snapshot('likes')['value']);self.assertEqual(server.snapshot('likes',True)['value'],5200);server.publish({'likes':42},'purple');self.assertEqual(server.snapshot('likes')['value'],42)
    def test_http(self):
        s=OverlayServer(0);s.start()
        try:
            with urllib.request.urlopen(s.url('likes')) as r:self.assertIn(b'transparent',r.read())
            with urllib.request.urlopen(s.url('likes').replace('/overlay/','/data/')) as r:self.assertIsNone(json.load(r)['value'])
        finally:s.close()
    def test_latest_tiktok(self):
        s=Stats();s.apply('follow','Luna');s.apply('follow','Alex');self.assertEqual(s.latest_follow,'Alex')
