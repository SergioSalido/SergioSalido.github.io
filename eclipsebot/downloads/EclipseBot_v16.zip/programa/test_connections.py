import unittest
from unittest.mock import patch, Mock, AsyncMock
import sys
from types import SimpleNamespace
from tiktok_module import Listener
from twitch import Twitch

class Connections(unittest.TestCase):
    def test_offline_wait(self):
        listener=Listener()
        with patch.object(listener,'run_once',return_value='offline') as attempt, patch.object(listener.stop,'wait',side_effect=lambda n:listener.stop.set()) as wait:
            listener.run('croonan74')
            attempt.assert_called_once_with('croonan74');wait.assert_called_once_with(45)
        self.assertEqual(listener.events.get_nowait(),('status','Desconectado'))
    def test_network_retry(self):
        listener=Listener()
        with patch.object(listener,'run_once',return_value='retry'),patch.object(listener.stop,'wait',side_effect=lambda n:listener.stop.set()) as wait:
            listener.run('croonan74');wait.assert_called_once_with(90)
    def test_missing_library_stops(self):
        listener=Listener()
        with patch.object(listener,'run_once',return_value='fatal'),patch.object(listener.stop,'wait') as wait:
            listener.run('croonan74');wait.assert_not_called()
    def test_twitch_offline_is_valid(self):
        t=Twitch('demo');t.token='fake';t.broadcaster='1'
        with patch('twitch.requests.get') as get:
            get.return_value=Mock(ok=True);get.return_value.json.return_value={'data':[]}
            self.assertFalse(t.stream_live());get.return_value.json.return_value={'data':[{'id':'123'}]};self.assertTrue(t.stream_live())
    def test_offline_probe_no_websocket(self):
        listener=Listener();client=Mock();client.is_live=AsyncMock(return_value=False);client.web.close=AsyncMock();client.connect=AsyncMock()
        events=SimpleNamespace(**{n:object for n in ('CommentEvent','LikeEvent','FollowEvent','GiftEvent','RoomUserSeqEvent','ConnectEvent','DisconnectEvent')})
        with patch.dict(sys.modules,{'TikTokLive':SimpleNamespace(TikTokLiveClient=Mock(return_value=client)),'TikTokLive.events':events}):
            self.assertEqual(listener.run_once('croonan74'),'offline')
        client.connect.assert_not_called();client.web.close.assert_awaited_once();self.assertEqual(listener.events.get_nowait()[0],'status');self.assertIn('Sin directo',listener.events.get_nowait()[1])
