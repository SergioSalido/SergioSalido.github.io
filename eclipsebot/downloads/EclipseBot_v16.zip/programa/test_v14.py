import tempfile, unittest
from alerts import Alerts, page
from panel import Panel
from unittest.mock import Mock, patch
import sys

class Version14Tests(unittest.TestCase):
    def test_legacy_colors(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=Alerts(tmp);a.save('tw-follow',{'color':'#123456'})
            c=a.config('tw-follow');self.assertEqual(c['frame_color'],'#123456');self.assertEqual(c['title_color'],'#123456');self.assertEqual(c['text_color'],'#ffffff')
    def test_independent_alert_colors(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=Alerts(tmp);c=a.config('tw-follow');c.update(frame_color='#123456',title_color='#abcdef',text_color='#fedcba');a.save('tw-follow',c)
            a=Alerts(tmp);a.emit('tw-follow','Ana');d=a.snapshot(0)['events'][0]
            self.assertEqual([d[k] for k in ('frame_color','title_color','text_color')],['#123456','#abcdef','#fedcba']);self.assertNotEqual(a.config('tw-sub')['frame_color'],'#123456')
    def test_html(self):
        html=page(False);self.assertNotIn('ECLIPSEBOT / LIVE ALERT',html)
        for name in ('frame','title','text'):self.assertIn("setProperty('--"+name+"'",html)
    def test_discord_unsynced(self):
        p=Panel(Mock());p.enabled=True;api=Mock()
        with patch.dict(sys.modules,{'pyautogui':api}):p.run('Silencia Discord')
        api.hotkey.assert_not_called()
    def test_discord_toggle(self):
        p=Panel(Mock());p.enabled=True;p.states={'mute':False,'deafen':False};api=Mock()
        with patch.dict(sys.modules,{'pyautogui':api}):
            p.run('Silencia Discord');p.run('Silencia Discord');p.run('Activa Discord')
        self.assertEqual(api.hotkey.call_count,2);self.assertFalse(p.states['deafen']);self.assertFalse(p.states['mute'])
