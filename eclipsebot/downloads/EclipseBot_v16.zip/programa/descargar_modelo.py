from pathlib import Path
from urllib.request import urlretrieve
from zipfile import ZipFile
import tempfile
import shutil

root=Path(__file__).resolve().parent/'models'
name='vosk-model-small-es-0.42'
if (root/name/'am'/'final.mdl').is_file():
    print('Modelo ya instalado.'); raise SystemExit(0)
root.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir=root) as tmp:
    tmp=Path(tmp); archive=tmp/'model.zip'
    print('Descargando el modelo oficial de Vosk en espanol (39 MB)...',flush=True)
    urlretrieve('https://alphacephei.com/vosk/models/'+name+'.zip',archive)
    with ZipFile(archive) as z:
        for item in z.infolist():
            dest=(tmp/item.filename).resolve()
            if not dest.is_relative_to(tmp.resolve()): raise RuntimeError('Ruta no segura en el ZIP.')
        z.extractall(tmp)
    if not (tmp/name/'am'/'final.mdl').is_file(): raise RuntimeError('Modelo incompleto.')
    if (root/name).exists(): shutil.rmtree(root/name)
    shutil.move(str(tmp/name),str(root/name))
print('Modelo instalado.')
