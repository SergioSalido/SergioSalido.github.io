"""Lightweight, reusable graphics for the native desktop UI (no extra runtime)."""
import tkinter as tk
from PIL import Image, ImageDraw, ImageTk, ImageFilter

def rgb(s):return tuple(int(s[i:i+2],16) for i in (1,3,5))
def blend(a,b,t):return tuple(round(x+(y-x)*t) for x,y in zip(a,b))
class Banner(tk.Canvas):
 def __init__(self,parent,title,height=32,large=False):
  super().__init__(parent,height=height,highlightthickness=0,bd=0,bg=parent.cget('bg'));self.title=title;self.large=large;self.bind('<Configure>',self.draw);self.bind('<<Palette>>',self.draw)
 def draw(self,event=None):
  w=self.winfo_width();h=self.winfo_height()
  if w<5:return
  root=self.winfo_toplevel();pal=getattr(root,'_palette',None);accent=pal[4] if pal else '#ff3448';fg=pal[3] if pal else '#f2e9ed';a=rgb(accent);bg=rgb(self.master.cget('bg'))
  im=Image.new('RGB',(w,h));d=ImageDraw.Draw(im)
  for y in range(h):
   t=y/max(1,h-1);base=blend(bg,(7,7,10),.25+.4*t);col=blend(base,a,.14*(1-t));d.line((0,y,w,y),fill=col)
  length=min(w-4, max(60,int(w*.62)));d.polygon([(1,1),(length,1),(length-22,h-2),(1,h-2)],fill=blend(bg,a,.23));d.line((1,h-2,length-22,h-2),fill=a,width=2);d.line((length-22,h-2,length,1),fill=a,width=1)
  for i in range(3):
   x=w-46+i*12
   if x>length:d.polygon([(x,6),(x+7,6),(x-5,h-6),(x-12,h-6)],fill=blend(bg,a,.55-i*.12))
  self.photo=ImageTk.PhotoImage(im);self.delete('all');self.create_image(0,0,image=self.photo,anchor='nw');self.create_text(10,h/2,text=self.title,anchor='w',fill=fg,font=('Segoe UI',22 if self.large else 12,'bold italic'))
