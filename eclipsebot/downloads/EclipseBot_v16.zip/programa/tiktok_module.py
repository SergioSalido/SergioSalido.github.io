"""Optional read-only TikTok LIVE integration; no session credentials."""
import asyncio
import queue
import re
import threading
import time
import tkinter as tk
from tkinter import ttk
from collections import deque


def normalize(value):
    value=value.strip().lstrip('@')
    if not re.fullmatch(r'[A-Za-z0-9_.]{1,24}',value):
        raise ValueError('Introduce tu nombre de usuario de TikTok, sin URL.')
    return value


def integer(value):
    try: return max(0,int(value))
    except (ValueError,TypeError): return 0


def event_data(kind,event):
    user=getattr(event,'user',None)
    name=getattr(user,'unique_id',None) or getattr(user,'nickname',None) or 'usuario'
    if kind=='chat': return (kind,(name,getattr(event,'content',None) or getattr(event,'comment','')))
    if kind=='like': return (kind,integer(getattr(event,'count',0)))
    if kind=='follow': return (kind,name)
    if kind=='gift':
        gift=getattr(event,'gift',None)
        if gift is None: return None
        if getattr(gift,'streakable',False) and not getattr(event,'repeat_end',0): return None
        return (kind,(name,getattr(gift,'name','regalo'),max(1,integer(getattr(event,'repeat_count',1)))))
    if kind=='viewers': return (kind,integer(getattr(event,'total',0)))


class Stats:
    def __init__(self): self.likes=self.follows=self.gifts=0; self.viewers=None; self.latest_follow=None; self.chat=deque(maxlen=200)
    def apply(self,kind,data):
        if kind=='like': self.likes+=data
        elif kind=='follow': self.follows+=1; self.latest_follow=data
        elif kind=='gift': self.gifts+=data[2]
        elif kind=='viewers': self.viewers=data
        elif kind=='chat': self.chat.append(data)


class Listener:
    def __init__(self): self.events=queue.Queue(maxsize=2000); self.stop=threading.Event(); self.thread=None
    def emit(self,kind,data):
        try: self.events.put_nowait((kind,data))
        except queue.Full: pass
    def start(self,user):
        user=normalize(user)
        if self.thread and self.thread.is_alive(): return False
        self.stop.clear(); self.thread=threading.Thread(target=self.run,args=(user,),daemon=True); self.thread.start(); return True
    def run(self,user):
        while not self.stop.is_set():
            outcome=self.run_once(user)
            if outcome=="fatal" or self.stop.is_set(): break
            self.stop.wait(45 if outcome=="offline" else 90)
        if self.stop.is_set(): self.emit("status","Desconectado")
    def run_once(self,user):
        async def main():
            from TikTokLive import TikTokLiveClient
            from TikTokLive.events import CommentEvent, LikeEvent, FollowEvent, GiftEvent, RoomUserSeqEvent, ConnectEvent, DisconnectEvent
            client=TikTokLiveClient(unique_id='@'+user)
            try:
                online=await asyncio.wait_for(client.is_live(),timeout=25)
            except Exception:
                try: await client.web.close()
                except Exception: pass
                raise
            if not online or self.stop.is_set():
                try: await client.web.close()
                except Exception: pass
                return False
            for cls,kind in [(CommentEvent,'chat'),(LikeEvent,'like'),(FollowEvent,'follow'),(GiftEvent,'gift'),(RoomUserSeqEvent,'viewers')]:
                async def receive(event,k=kind):
                    data=event_data(k,event)
                    if data: self.emit(*data)
                client.add_listener(cls,receive)
            async def connected(event):
                self.emit('session',None); self.emit('status','Conectado · solo lectura')
            async def disconnected(event): self.emit('status','LIVE desconectado')
            client.add_listener(ConnectEvent,connected); client.add_listener(DisconnectEvent,disconnected)
            task=asyncio.ensure_future(client.connect())
            try:
                while not task.done() and not self.stop.is_set(): await asyncio.wait([task],timeout=.25)
                if self.stop.is_set() and not task.done():
                    try: await asyncio.wait_for(client.disconnect(),timeout=5)
                    except Exception: pass
                    task.cancel(); await asyncio.gather(task,return_exceptions=True)
                else: await task
                return True
            finally:
                try: await client.web.close()
                except Exception: pass
        self.emit('status','Conectando…')
        try: online=asyncio.run(main())
        except ImportError:
            self.emit('status','Librería TikTokLive no instalada (componente opcional)'); return 'fatal'
        except Exception as e:
            name=type(e).__name__
            if name=='UserOfflineError':
                self.emit('status','Sin directo · esperando (45 s)'); return 'offline'
            self.emit('status','No se pudo verificar LIVE: '+name+' · reintento en 90 s'); return 'retry'
        else:
            if not self.stop.is_set(): self.emit('status',('LIVE finalizado' if online else 'Sin directo')+' · esperando (45 s)')
            return 'offline' 


class TikTokPanel:
    def __init__(self,app): self.app=app; self.listener=Listener(); self.stats=Stats(); self.window=None; self.status='Desconectado'; self.user=''; self.demo=False
    def open(self):
        if self.window and self.window.winfo_exists(): self.window.lift(); return
        w=self.window=tk.Toplevel(self.app); w.title('EclipseBot · TikTok LIVE · PRÓXIMAMENTE'); w.geometry('660x510'); w.configure(bg='#222328')
        f=ttk.Frame(w,padding=12); f.pack(fill='both',expand=True)
        ttk.Label(f,text='TikTok LIVE · PRÓXIMAMENTE',foreground='#85878d').pack(anchor='w'); self.entry=ttk.Entry(f,state='disabled'); self.entry.pack(fill='x')
        buttons=ttk.Frame(f); buttons.pack(fill='x',pady=8)
        ttk.Button(buttons,text='Conectar',command=self.connect,state='disabled').pack(side='left'); ttk.Button(buttons,text='Desconectar',command=self.listener.stop.set,state='disabled').pack(side='left'); ttk.Button(buttons,text='Simular eventos',command=self.simulate).pack(side='left')
        self.label=ttk.Label(f,text=self.status); self.label.pack(anchor='w'); self.summary=ttk.Label(f); self.summary.pack(anchor='w',pady=6)
        self.log=tk.Text(f,height=13,bg='#15151c',fg='white',state='disabled'); self.log.pack(fill='both',expand=True)
        ttk.Label(f,text='La integración no oficial se conserva en el proyecto, pero permanece desactivada en esta versión.',foreground='#9b9da3',wraplength=600).pack(anchor='w',pady=6)
        self.refresh(); w.after(200,self.poll)
    def connect(self):
        self.status='PRÓXIMAMENTE · conexión desactivada';self.refresh();return
        try:
            user=normalize(self.entry.get())
            if self.listener.start(user): self.user=user; self.stats=Stats(); self.demo=False; self.status='Conectando…'; self.refresh()
        except ValueError as e: self.status=str(e); self.refresh()
    def simulate(self):
        if self.listener.thread and self.listener.thread.is_alive(): return
        self.demo=True; self.stats=Stats(); self.status='SIMULACIÓN · datos ficticios';
        for kind,data in [('chat',('EspectadorDemo','¡Buenas!')),('like',12),('follow','Demo'),('gift',('Demo','Rosa',3)),('viewers',5)]: self.stats.apply(kind,data)
        self.refresh()
    def refresh(self):
        s=self.stats; self.label.configure(text=self.status); self.summary.configure(text=f'Likes recibidos: {s.likes}   Seguimientos: {s.follows}   Regalos: {s.gifts}   Espectadores: {s.viewers if s.viewers is not None else "—"}')
        self.log.configure(state='normal'); self.log.delete('1.0','end'); self.log.insert('end','\n'.join(f'{u}: {m}' for u,m in s.chat)); self.log.see('end'); self.log.configure(state='disabled')
    def poll(self):
        if not self.window or not self.window.winfo_exists(): self.listener.stop.set(); return
        changed=False
        for _ in range(200):
            try: kind,data=self.listener.events.get_nowait()
            except queue.Empty: break
            changed=True
            if kind=='status': self.status=data
            else: self.stats.apply(kind,data)
        if changed: self.refresh()
        self.window.after(200,self.poll)
