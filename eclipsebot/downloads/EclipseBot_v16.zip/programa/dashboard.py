import tkinter as tk
from tkinter import ttk
import time, queue, json, threading, webbrowser
from identity import apply_icon, apply_dark_titlebar, clean_name, themed_icon, apply_theme_icon
from collections import deque
from app import App, BASE, MODEL
from user_data import DATA_DIR
from core import CHANNEL
from chatfeed import TwitchFeed
from tiktok_module import normalize, Stats
from extras import editor
from overlays import OverlayServer, Gallery
from alerts import AlertGallery
from twitch_alerts import TwitchAlerts
from PIL import Image, ImageDraw, ImageTk
from visual import Banner
BG='#100b0e'; SIDE='#181014'; CARD='#211318'; FG='#f2e9ed'; MUT='#b2a4ac'; RED='#ff3448'; PUR='#aa79ff'; CYAN='#39d8d1'
class Dashboard(App):
    def __init__(self):
        super().__init__(); self.children_wrap=next(w for w in self.winfo_children() if isinstance(w,ttk.Frame));self.children_wrap.pack_forget()
        style=ttk.Style(self);style.configure('TNotebook',background=BG,borderwidth=0);style.configure('TNotebook.Tab',background=CARD,foreground=MUT,padding=(12,8));style.map('TNotebook.Tab',background=[('selected','#353342')],foreground=[('selected',FG)]);style.configure('TCheckbutton',background=CARD,foreground=FG);self.title('EclipseBot 16 · Stream Control');apply_icon(self);apply_dark_titlebar(self);self.geometry(f'{min(1450,self.winfo_screenwidth()-24)}x{min(850,self.winfo_screenheight()-70)}');self.minsize(950,620);self.configure(bg=BG)
        self.feed=TwitchFeed();self.feed_obj=None;self.feed_status='Desconectado';self.messages=deque(maxlen=500);self.chatviews=[];self.logos=self.make_logos();self.demo=False;self.floatwin=None;self.pages={};self.nav={};self.filter=tk.StringVar(value='Todos');self.pin=tk.BooleanVar(value=True);self.ttuser=tk.StringVar();self.ttaccount=tk.StringVar(value="Sin usuario guardado");self.tt_enabled=tk.BooleanVar(value=False);self.ttauto=tk.BooleanVar(value=False);self.twcode=tk.StringVar(value="");self.twlive=tk.StringVar(value="Directo: sin comprobar");self.ttstatus=tk.StringVar(value='Integración TikTok desactivada');self.statsvar=tk.StringVar(value='—');self.refreshvar=tk.StringVar();self.demo_label=tk.StringVar(value='MODO PRUEBA · sin conexiones reales');self.voicevar=tk.StringVar(value='Detenido');self.twitchchat=tk.StringVar(value='Desconectado');self.countvar=tk.StringVar(value='0');self.autoscroll=tk.BooleanVar(value=True);self.app_theme="red";self.display_name=tk.StringVar(value="Croonan74")
        self.sidebar_width=208
        try:
            saved=json.loads((DATA_DIR/'ui.json').read_text());self.display_name.set(clean_name(saved.get('display_name','Croonan74')));self.ttuser.set(saved.get('tiktok',''));self.tt_enabled.set(False);self.ttauto.set(False);self.pin.set(saved.get('pin',True));self.autoscroll.set(saved.get('autoscroll',True));self.app_theme=saved.get('app_theme','red') if saved.get('app_theme','red') in ('red','purple','cyan','orange') else 'red'
        except Exception:pass
        try:self.sidebar_width=max(68,min(280,int(saved.get('sidebar_width',208))))
        except (NameError,ValueError,TypeError):pass
        sidebar=tk.Frame(self,bg=SIDE,width=208,highlightthickness=1,highlightbackground=RED);sidebar.pack(side='left',fill='y');sidebar.pack_propagate(False);self.sidebar=sidebar;self.nav_icons={}
        self.brand_label=tk.Label(sidebar,bg=SIDE,bd=0);self.brand_label.pack(pady=(12,0));self.brand_text=self.label(sidebar,'ECLIPSEBOT',17,FG,True);self.brand_text.pack(anchor='center');self.brand_version=self.label(sidebar,'STREAM CONTROL  /  16',9,MUT);self.brand_version.pack(anchor='center',pady=(1,10))
        self.sidebar_grip=tk.Frame(self,bg=RED,width=6,cursor='sb_h_double_arrow');self.sidebar_grip.pack(side='left',fill='y');self.sidebar_grip.pack_propagate(False)
        self.sidebar_grip.bind('<ButtonPress-1>',lambda e:setattr(self,'_sidebar_drag',(e.x_root,self.sidebar_width)))
        self.sidebar_grip.bind('<B1-Motion>',lambda e:self.resize_sidebar(self._sidebar_drag[1]+e.x_root-self._sidebar_drag[0]) if hasattr(self,'_sidebar_drag') else None)
        self.sidebar_grip.bind('<ButtonRelease-1>',lambda e:self.save_all())
        self.sidebar_grip.bind('<Double-Button-1>',lambda e:(self.resize_sidebar(208 if self.sidebar_width<150 else 68),self.save_all()))
        self.main=tk.Frame(self,bg=BG);self.main.pack(side='left',fill='both',expand=True,padx=25,pady=20)
        for name,ico in [('Inicio','⌂'),('Twitch','▣'),('TikTok','♪'),('Chat unificado','▤'),('Panel táctil','▦'),('Overlays','◇'),('Alertas','✦'),('Historial','◷'),('Ajustes','⚙')]:
            b=tk.Button(sidebar,text=f'  {ico}   {name}',anchor='w',bd=0,bg=SIDE,fg=MUT,activebackground=CARD,activeforeground=FG,font=('Segoe UI',11,'bold italic'),padx=15,pady=10,highlightthickness=1,highlightbackground=SIDE,command=lambda n=name:self.show(n),cursor='hand2',relief='flat',overrelief='raised');b.pack(fill='x',padx=12,pady=2);self.nav[name]=b;self.nav_icons[name]=ico
            b.bind('<Enter>',lambda e,button=b:button.configure(bg='#30232e',fg=FG,highlightbackground=RED))
            b.bind('<Leave>',lambda e,button=b,n=name:self.restore_nav_hover(button,n))
        profile_label=self.label(sidebar,size=11,color=FG,bold=True,var=self.display_name);profile_label.configure(wraplength=165);profile_label.pack(side='bottom',anchor='w',padx=23,pady=25);self.profile_label=profile_label;self.resize_sidebar(self.sidebar_width)
        for name in self.nav:self.pages[name]=tk.Frame(self.main,bg=BG)
        self.alert_feed=TwitchAlerts();self.overlay_server=OverlayServer();self.follow_obj=None;self.follow_result=None;self.follow_queue=queue.Queue();self.follow_busy=False;self.follow_at=0
        try:self.overlay_server.start()
        except OSError:self.log('Overlays: puerto local 8765 no disponible.')
        self.home();self.platforms();self.chatpage();self.touchpage();self.gallery=Gallery(self,self.pages['Overlays']);self.alert_gallery=AlertGallery(self,self.pages['Alertas']);self.historypage();self.settingspage();self.show('Inicio');self._palette=None;self.apply_theme(self.app_theme);self.after(200,self.tick);self.refresh_ttaccount();self.after(600,self.connect_tt) if self.tt_enabled.get() and self.ttauto.get() and self.ttuser.get() else None
    def resize_sidebar(self,width):
        self.sidebar_width=max(68,min(280,int(width)));compact=self.sidebar_width<155
        self.sidebar.configure(width=self.sidebar_width)
        self.brand_text.configure(text='' if compact else 'ECLIPSEBOT');self.brand_version.configure(text='16' if compact else 'STREAM CONTROL  /  16')
        self.profile_label.configure(wraplength=max(40,self.sidebar_width-30));self.profile_label.pack_configure(padx=8 if compact else 23)
        for name,b in self.nav.items():
            b.configure(text=self.nav_icons[name] if compact else f'  {self.nav_icons[name]}   {name}',anchor='center' if compact else 'w',padx=3 if compact else 15)
            b.pack_configure(padx=5 if compact else 12)
    def label(self,p,t='',size=11,color=FG,bold=False,var=None):return tk.Label(p,text=t,textvariable=var,bg=p.cget('bg'),fg=color,font=('Segoe UI',size,'bold italic' if bold else 'normal'),anchor='w',justify='left')
    def restore_nav_hover(self,button,name):
        pal=getattr(self,'_palette',None) or (BG,SIDE,CARD,FG,RED);selected=getattr(self,'current_page',None)==name
        button.configure(bg=pal[1],fg=pal[4] if selected else MUT,highlightbackground=pal[4] if selected else pal[1])
    def btn(self,p,t,fn,accent=False):
        pal=getattr(self,'_palette',None) or (BG,SIDE,CARD,FG,RED)
        b=tk.Button(p,text=t,command=fn,bg=pal[2],fg=pal[3],activebackground=pal[4],activeforeground='white',bd=0,highlightthickness=1,highlightbackground=pal[2],padx=12,pady=8,font=('Segoe UI',10,'bold italic'),cursor='hand2',relief='flat',overrelief='raised',takefocus=True)
        b._action_button=True
        b.bind('<Enter>',lambda e:b.configure(bg=(getattr(self,'_palette',None) or pal)[4],fg='white',highlightbackground=(getattr(self,'_palette',None) or pal)[4],highlightthickness=2,relief='raised'))
        b.bind('<Leave>',lambda e:b.configure(bg=(getattr(self,'_palette',None) or pal)[2],fg=(getattr(self,'_palette',None) or pal)[3],highlightbackground=(getattr(self,'_palette',None) or pal)[2],highlightthickness=1,relief='flat'))
        return b
    def head(self,p,t,sub):
        f=tk.Frame(p,bg=CARD,highlightthickness=1,highlightbackground=RED,padx=15,pady=8);f.pack(fill='x',pady=(0,12));Banner(f,t.upper(),46,True).pack(fill='x');self.label(f,sub,10,MUT).pack(anchor='w',pady=(2,0))
    def card(self,p,title):
        f=tk.Frame(p,bg=CARD,padx=13,pady=9,highlightthickness=1,highlightbackground=RED);f.pack(fill='x',pady=(0,8));Banner(f,title.upper()).pack(fill='x',pady=(0,6));return f
    def row(self,p):r=tk.Frame(p,bg=p.cget('bg'));r.pack(fill='x',pady=4);return r
    def buttons(self,p,items):r=self.row(p);[self.btn(r,t,fn).pack(side='left',padx=(0,7)) for i,(t,fn) in enumerate(items)];return r
    def field(self,p,t,var):r=self.row(p);self.label(r,t,10,MUT).pack(side='left');e=ttk.Entry(r,textvariable=var,width=43);e.pack(side='right',fill='x',expand=True,padx=(18,0));return e
    def show(self,n):
        self.current_page=n;palette=getattr(self,'_palette',None);side=palette[1] if palette else SIDE;accent=palette[4] if palette else RED
        for k,p in self.pages.items():p.pack_forget();self.nav[k].configure(bg=side,fg=accent if k==n else MUT,relief='groove' if k==n else 'flat')
        self.pages[n].pack(fill='both',expand=True)
        if n=='Historial':self.refresh_history()
    def home(self):
        p=self.pages['Inicio'];self.head(p,'Centro de control','Tu directo, tus herramientas, todo en un solo lugar.');self.label(p,var=self.demo_label,color=RED,bold=True).pack(anchor='w',pady=(0,12));r=self.row(p)
        for title,var,color in [('TWITCH',self.status,PUR),('TIKTOK LIVE',self.ttstatus,CYAN),('VOZ',self.voicevar,RED)]:
            f=tk.Frame(r,bg=CARD,padx=13,pady=15);f.pack(side='left',fill='both',expand=True,padx=(0,8));self.label(f,title,10,color,True).pack(anchor='w');self.label(f,var=var,size=10).pack(anchor='w',pady=10)
        f=self.card(p,'Reconocimiento de voz');self.label(f,var=self.heard,color=MUT).pack(anchor='w');self.buttons(f,[('Escuchar micrófono',self.start_audio),('Detener',self.stop_audio),('Simular Discord',lambda:self.trigger('discord',True))]);f=self.card(p,'Accesos rápidos');self.buttons(f,[('Abrir chat flotante',self.floating),('Panel XENEON EDGE',self.panel.open),('Configurar conexiones',lambda:self.show('Ajustes'))]);f=self.card(p,'Sesión actual');self.label(f,var=self.countvar,color=MUT).pack(anchor='w');self.buttons(f,[('Probar chat con ejemplos',self.simulate),('Minimizar a bandeja',self.panel.hide)])
    def platforms(self):
        p=self.pages['Twitch'];self.head(p,'Twitch','Gestiona Croonan74 · comandos e interacción del directo.');f=self.card(p,'Estado del canal');self.label(f,var=self.status,color=PUR).pack(anchor='w');self.label(f,var=self.twitchchat,color=MUT).pack(anchor='w');self.buttons(f,[('Configurar conexión',lambda:self.show('Ajustes')),('Ver chat',lambda:self.show('Chat unificado'))]);f=self.card(p,'Acciones del directo');self.buttons(f,[(c,lambda c=c:self.panel.run(c,manual=True)) for c in ['Clip','Encuesta','Inicia una apuesta']]);self.buttons(f,[(c,lambda c=c:self.panel.run(c,manual=True)) for c in ['Finaliza encuesta','Finalizar apuesta','Cancela apuesta']]);f=self.card(p,'Comandos sociales');self.buttons(f,[(c,lambda c=c:self.panel.run(c,manual=True)) for c in ['Discord','YouTube','Instagram','Mi PC']]);
        p=self.pages['TikTok'];self.head(p,'TikTok LIVE · PRÓXIMAMENTE','Integración pausada · esta versión no se conecta a TikTok LIVE.');disabled=tk.Frame(p,bg='#28292e',padx=24,pady=24,highlightthickness=1,highlightbackground='#505158');disabled.pack(fill='both',expand=True);tk.Label(disabled,text='TIKTOK LIVE',bg='#28292e',fg='#a5a6aa',font=('Segoe UI',19,'bold italic')).pack(anchor='center',pady=(35,8));tk.Label(disabled,text='PRÓXIMAMENTE',bg='#28292e',fg='#85878d',font=('Segoe UI',14,'bold')).pack(anchor='center',pady=6);tk.Label(disabled,text='La integración no oficial se conserva en el proyecto, pero está desactivada.\nNo se instala la librería ni se realizan conexiones.',bg='#28292e',fg='#9b9da3',font=('Segoe UI',10),justify='center').pack(anchor='center',pady=8)
    def chatpage(self):
        p=self.pages['Chat unificado'];self.head(p,'Chat unificado','Twitch y TikTok en una sola conversación.');r=self.row(p);self.btn(r,'Abrir ventana flotante',self.floating,True).pack(side='left');self.btn(r,'Simular mensajes',self.simulate).pack(side='left',padx=8);self.btn(r,'Limpiar',self.clear_chat).pack(side='left');ttk.Combobox(r,textvariable=self.filter,values=['Todos','Twitch','TikTok'],state='readonly',width=12).pack(side='right');self.filter.trace_add('write',lambda *_:self.render_chat());self.label(p,var=self.demo_label,color=MUT).pack(anchor='w',pady=5);self.make_chat(p)
    def make_logos(self):
        icons={}
        for name in ('Twitch','TikTok'):
            im=Image.new('RGBA',(48,48));d=ImageDraw.Draw(im)
            if name=='Twitch':
                d.polygon([(8,3),(44,3),(44,29),(32,41),(24,41),(16,47),(16,37),(6,37),(6,10)],fill=PUR)
                d.polygon([(13,8),(39,8),(39,27),(29,35),(23,35),(19,39),(19,30),(13,30)],fill='#1c1f28')
                d.rectangle((22,13,25,24),fill=PUR);d.rectangle((31,13,34,24),fill=PUR)
            else:
                for dx,dy,col in [(2,1,'#ff466c'),(-1,0,CYAN),(0,0,'#ffffff')]:
                    d.line([(27+dx,7+dy),(27+dx,31+dy)],fill=col,width=8);d.ellipse((10+dx,25+dy,31+dx,45+dy),fill=col);d.ellipse((17+dx,31+dy,23+dx,37+dy),fill='#1c1f28');d.line([(27+dx,8+dy),(34+dx,16+dy),(41+dx,17+dy)],fill=col,width=7)
            icons[name]=ImageTk.PhotoImage(im.resize((18,18),Image.Resampling.LANCZOS))
        return icons
    def make_chat(self,p):
        t=tk.Text(p,bg=CARD,fg=FG,bd=0,padx=14,pady=12,wrap='word',font=('Segoe UI',12),state='disabled');t.pack(fill='both',expand=True);t.tag_config('Twitch',foreground=PUR,font=('Segoe UI',11,'bold'));t.tag_config('TikTok',foreground=CYAN,font=('Segoe UI',11,'bold'));t.tag_config('time',foreground=MUT,font=('Segoe UI',9));self.chatviews.append(t);self.render_chat();return t
    def floating(self):
        if self.floatwin and self.floatwin.winfo_exists():self.floatwin.lift();return
        w=self.floatwin=tk.Toplevel(self);w.title('EclipseBot · Chat flotante');apply_icon(w);w.geometry('430x560');w.configure(bg=BG);w.attributes('-topmost',self.pin.get());f=tk.Frame(w,bg=BG,padx=10,pady=10);f.pack(fill='both',expand=True);self.label(f,'CHAT EN DIRECTO',15,FG,True).pack(anchor='w');ttk.Checkbutton(f,text='Siempre encima',variable=self.pin,command=lambda:w.attributes('-topmost',self.pin.get())).pack(anchor='w');self.label(f,var=self.demo_label,color=MUT,size=9).pack(anchor='w',pady=4);self.make_chat(f)
    def add_chat(self,platform,user,msg):self.messages.append((time.strftime('%H:%M'),platform,str(user),str(msg)));self.render_chat()
    def clear_chat(self):self.messages.clear();self.render_chat()
    def render_chat(self):
        self.chatviews=[t for t in self.chatviews if t.winfo_exists()]
        for t in self.chatviews:
            at=t.yview()[1]>=.98;t.configure(state='normal');t.delete('1.0','end')
            for tm,platform,user,msg in self.messages:
                if self.filter.get() not in ('Todos',platform):continue
                t.insert('end',tm+'  ','time');t.image_create('end',image=self.logos[platform]);t.insert('end','  '+platform.upper()+'  '+user+'\n',platform);t.insert('end',msg+'\n\n')
            t.configure(state='disabled');
            if at or self.autoscroll.get():t.see('end')
    def simulate(self):
        if self.twitch or (self.tiktok_panel.listener.thread and self.tiktok_panel.listener.thread.is_alive()):return
        self.demo=True;self.demo_label.set('SIMULACIÓN · mensajes y estadísticas ficticios');self.clear_chat()
        for a,b,c in [('Twitch','Lastras','¡Buenas! ¿Fortnite hoy?'),('TikTok','Marta','Holaaa, acabo de llegar'),('Twitch','David','¿Nos pasas el Discord?'),('TikTok','Alex','Qué buena partida 🔥'),('Twitch','CroonanFan','Una más y ganamos'),('TikTok','Luna','Saludos desde TikTok!')]:self.add_chat(a,b,c)
        self.tiktok_panel.stats=Stats();self.tiktok_panel.stats.apply('like',124);self.tiktok_panel.stats.apply('viewers',8);self.tiktok_panel.stats.apply('gift',('Demo','Rosa',3));self.tiktok_panel.stats.apply('follow','Demo')
    def touchpage(self):
        from skin import TouchSkin
        p=self.pages['Panel táctil'];self.head(p,'Panel táctil','Controles reales · personalización independiente de la aplicación.')
        self.panel.embedded_skin=TouchSkin(self.panel,p,embedded=True)
    def theme_controls(self,p):
        from skin import THEMES
        f=self.card(p,'Estilo general de EclipseBot');self.label(f,'Este tema solo afecta a la aplicación, no al panel táctil.',10,MUT).pack(anchor='w');r=self.row(f);self.theme_buttons={}
        for k,v in THEMES.items():
            b=self.btn(r,v[0],lambda k=k:self.set_app_theme(k));b.pack(side='left',padx=(0,7));self.theme_buttons[k]=(b,v[0])
    def refresh_theme_buttons(self):
        _,_,card,fg,accent=self._palette
        for k,(b,label) in self.theme_buttons.items():
            selected=k==self.app_theme
            b.configure(text=('✓ ' if selected else '  ')+label,bg=accent if selected else card,fg='white' if selected else fg,highlightbackground=accent if selected else card,activebackground=accent)
    def set_app_theme(self,key):
        self.app_theme=key;self.apply_theme(key);self.save_all()
    def apply_theme(self,key):
        from skin import THEMES
        _,bg,card,fg,accent=THEMES[key];old=self._palette or (BG,SIDE,CARD,FG,RED)
        new=(bg,card,card,fg,accent);mapping=dict(zip(old,new));mapping.update({'#303542':card,'#30232e':card,'#535c70':accent})
        def visit(w):
            if getattr(w,'_touch_scope',False):return
            for opt in ('bg','fg','activebackground','activeforeground','highlightbackground','insertbackground'):
                try:
                    val=w.cget(opt)
                    if val in mapping:w.configure(**{opt:mapping[val]})
                except (tk.TclError,TypeError):pass
            if getattr(w,'_action_button',False):w.configure(bg=card,fg=fg,activebackground=accent,highlightbackground=card)
            for child in w.winfo_children():visit(child)
        visit(self);self._palette=new;self.refresh_theme_buttons()
        self.brand=ImageTk.PhotoImage(themed_icon(accent,66),master=self);self.brand_label.configure(image=self.brand,bg=card);self.brand_text.configure(fg=accent,bg=card)
        apply_theme_icon(self,accent)
        if self.panel.tray:self.panel.tray.icon=themed_icon(accent,64)
        def redraw(w):
            if getattr(w,'_touch_scope',False):return
            if isinstance(w,Banner):w.draw()
            for child in w.winfo_children():redraw(child)
        redraw(self)
        self.option_add('*Toplevel.background',bg)
        style=ttk.Style(self);style.theme_use('clam');style.configure('.',background=bg,foreground=fg,fieldbackground=card,bordercolor=accent);style.configure('TButton',background=card,foreground=fg);style.map('TButton',background=[('active',accent)]);style.configure('TNotebook',background=bg);style.configure('TNotebook.Tab',background=card,foreground=fg);style.configure('TCheckbutton',background=card,foreground=fg)
        style.configure('TEntry',fieldbackground=card,foreground=fg,insertcolor=fg,padding=5);style.configure('TCombobox',fieldbackground=card,foreground=fg,arrowcolor=fg,padding=4);style.map('TCombobox',fieldbackground=[('readonly',card)],foreground=[('readonly',fg)]);style.configure('TCheckbutton',indicatorcolor=card);style.map('TCheckbutton',indicatorcolor=[('selected',accent)],background=[('active',card)]);style.configure('TNotebook.Tab',padding=(12,8));style.map('TNotebook.Tab',background=[('selected',accent)],foreground=[('selected','#ffffff')]);
        if hasattr(self,'gallery'):self.gallery.draw()
        if hasattr(self,'current_page'):self.show(self.current_page)

    def historypage(self):p=self.pages['Historial'];self.head(p,'Historial','Registro local de las acciones del bot.');self.btn(p,'Actualizar',self.refresh_history).pack(anchor='w',pady=6);self.hist=tk.Text(p,bg=CARD,fg=FG,bd=0,wrap='word');self.hist.pack(fill='both',expand=True)
    def refresh_history(self):self.hist.configure(state='normal');self.hist.delete('1.0','end');self.hist.insert('end',self.logbox.get('1.0','end'));self.hist.configure(state='disabled');self.hist.see('end')
    def settingspage(self):
        p=self.pages['Ajustes'];self.head(p,'Ajustes','Conexiones, audio, seguridad y personalización.'); self.btn(p,'Guardar ajustes',self.save_all,True).pack(side='bottom',anchor='e',pady=(8,0));tabs=ttk.Notebook(p);tabs.pack(fill='both',expand=True)
        for title in ['Conexiones','Audio y voz','Comandos','Apariencia','General']:
            f=tk.Frame(tabs,bg=BG,padx=10,pady=10);tabs.add(f,text=title)
            if title=='Conexiones':
                c=self.card(f,'Twitch · Cuenta');self.field(c,'Client ID',self.client);self.label(c,var=self.status,color=PUR).pack(anchor='w');self.label(c,var=self.twcode,color=FG).pack(anchor='w');self.label(c,var=self.twlive,color=MUT).pack(anchor='w');self.buttons(c,[('Autorizar cuenta',self.connect),('Desconectar',self.disconnect),('Crear Client ID',lambda:webbrowser.open('https://dev.twitch.tv/console/apps'))]);ttk.Checkbutton(c,text='Permitir publicaciones reales en Twitch',variable=self.live,command=self.toggle_live).pack(anchor='w');self.label(c,'OAuth funciona sin estar en directo. El chat se conecta por separado.',10,MUT).pack(anchor='w')
                c=tk.Frame(f,bg='#28292e',padx=13,pady=12,highlightthickness=1,highlightbackground='#505158');c.pack(fill='x',pady=(0,8));tk.Label(c,text='TIKTOK LIVE · PRÓXIMAMENTE',bg='#28292e',fg='#a5a6aa',font=('Segoe UI',11,'bold italic')).pack(anchor='w',pady=(0,5));tk.Label(c,text='La librería TikTokLive se conserva en el código, pero la conexión está desactivada.',bg='#28292e',fg='#9b9da3',wraplength=650,justify='left').pack(anchor='w');self.ttuser_row=tk.Frame(c,bg='#28292e');self.ttuser_row.pack(fill='x',pady=6);tk.Label(self.ttuser_row,text='Usuario TikTok',bg='#28292e',fg='#85878d').pack(side='left');self.ttuser_entry=ttk.Entry(self.ttuser_row,textvariable=self.ttuser,state='disabled');self.ttuser_entry.pack(side='right',fill='x',expand=True,padx=(12,0));self.ttstatus.set('PRÓXIMAMENTE · conexión desactivada');self.tt_connect_btn=ttk.Button(c,text='Conectar',command=self.connect_tt,state='disabled');self.tt_connect_btn.pack(anchor='w',pady=3);tk.Label(c,text='No se instala la librería y no se realizan conexiones.',bg='#28292e',fg='#85878d').pack(anchor='w')
                c=self.card(f,'Diagnóstico');self.buttons(c,[('Verificar conexiones',lambda:__import__('diagnostics').settings_window(self))]);self.label(c,'OBS: sin conexión directa · Discord: atajos locales',10,MUT).pack(anchor='w')
            elif title=='Audio y voz':
                c=self.card(f,'Micrófono y Vosk');r=self.row(c);self.label(r,'Dispositivo',10,MUT).pack(side='left');cb=ttk.Combobox(r,textvariable=self.device,values=list(self.device_ids),state='readonly');cb.pack(side='right',fill='x',expand=True);self.buttons(c,[('Actualizar dispositivos',lambda:(self.refresh_devices(),cb.configure(values=list(self.device_ids)))),('Escuchar',self.start_audio),('Detener',self.stop_audio)]);self.label(c,'Modelo local: '+('instalado' if MODEL.is_dir() else 'no instalado'),10,MUT).pack(anchor='w')
            elif title=='Comandos':
                c=self.card(f,'Comandos de voz · compartir enlaces');self.field(c,'Palabra de activación',self.aliases);self.field(c,'Mensaje de Discord',self.message);self.field(c,'Espera antispam (segundos)',self.seconds);self.buttons(c,[('Editar enlaces y mensajes',lambda:self.panel.settings('links'))]);c=self.card(f,'Control de llamada de Discord');self.label(c,'Configura los atajos de micro y sonido. No afecta a OBS.',10,MUT).pack(anchor='w');self.buttons(c,[('Configurar Discord',lambda:self.panel.settings('discord'))])
            elif title=='Apariencia':
                self.theme_controls(f)
            else:
                c=self.card(f,'Tu perfil');self.field(c,'Nombre visible',self.display_name);self.label(c,'Nombre de presentación; no cambia la cuenta conectada.',10,MUT).pack(anchor='w');c=self.card(f,'Ventanas y privacidad');ttk.Checkbutton(c,text='Chat flotante siempre encima',variable=self.pin,command=self.apply_pin).pack(anchor='w');ttk.Checkbutton(c,text='Desplazamiento automático del chat',variable=self.autoscroll).pack(anchor='w');self.label(c,'Los tokens no se guardan en disco. El chat unificado se mantiene en memoria.',10,MUT).pack(anchor='w',pady=10);self.buttons(c,[('Minimizar a bandeja',self.panel.hide)])
    def apply_pin(self):
        if self.floatwin and self.floatwin.winfo_exists():self.floatwin.attributes('-topmost',self.pin.get())
    def save_all(self):self.display_name.set(clean_name(self.display_name.get()));self.save_settings();(DATA_DIR/'ui.json').write_text(json.dumps({'display_name':self.display_name.get(),'tiktok':self.ttuser.get(),'tiktok_enabled':False,'tiktok_auto':False,'pin':self.pin.get(),'autoscroll':self.autoscroll.get(),'app_theme':self.app_theme,'sidebar_width':self.sidebar_width}),encoding='utf-8')
    def refresh_ttaccount(self):
        try: user=normalize(self.ttuser.get());self.ttaccount.set('Perfil configurado: @'+user+' (sin verificar titularidad)')
        except ValueError:self.ttaccount.set('Sin usuario guardado')
    def connect_tt(self):
        if not self.tt_enabled.get():
            self.ttstatus.set('PRÓXIMAMENTE · conexión desactivada');return
        try:
            user=normalize(self.ttuser.get());listener=self.tiktok_panel.listener
            if listener.thread and listener.thread.is_alive():
                self.log('TikTok: detén la escucha anterior antes de cambiar de perfil.');return
            self.ttuser.set(user);self.save_all();self.refresh_ttaccount();self.end_demo();self.tiktok_panel.stats=Stats();self.tiktok_panel.listener.start(user);self.ttstatus.set('Buscando LIVE…')
        except ValueError as e:self.ttstatus.set(str(e))
    def stop_tt(self):
        self.tiktok_panel.listener.stop.set();self.ttstatus.set('Deteniendo escucha…' if self.tiktok_panel.listener.thread and self.tiktok_panel.listener.thread.is_alive() else 'Desconectado');self.ttauto.set(False);self.save_all()
    def forget_tt(self):
        self.stop_tt();self.ttuser.set('');self.save_all();self.refresh_ttaccount()
    def end_demo(self):
        if self.demo:self.demo=False;self.clear_chat();self.tiktok_panel.stats=Stats();self.demo_label.set('Datos de sesión · sin simulación')
    def tick(self):
        if self.feed_obj is not self.twitch:
            self.alert_feed.stop.set();self.alert_feed=TwitchAlerts();self.feed.stop.set();self.feed=TwitchFeed();self.feed_obj=self.twitch;self.twitchchat.set('Desconectado')
            if self.twitch:self.end_demo();self.twitchchat.set('Conectando chat…');self.feed.start(self.twitch,CHANNEL);self.alert_feed.start(self.twitch)
        for source,q in [('Twitch',self.feed.events),('TikTok',self.tiktok_panel.listener.events)]:
            for _ in range(100):
                try:k,v=q.get_nowait()
                except queue.Empty:break
                if k=='status':
                    if source=='TikTok' and self.tiktok_panel.listener.stop.is_set() and v!='Desconectado':continue
                    (self.twitchchat if source=='Twitch' else self.ttstatus).set(v)
                else:
                    if source=='TikTok' and k=='session':self.tiktok_panel.stats=Stats();continue
                    if source=='TikTok':self.tiktok_panel.stats.apply(k,v)
                    if k=='chat':self.add_chat(source,*v)
                    if source=='TikTok' and not self.demo and not self.tiktok_panel.listener.stop.is_set() and self.ttstatus.get().startswith('Conectado'):
                        if k=='follow':self.overlay_server.alerts.emit('tt-follow',v)
                        elif k=='gift':self.overlay_server.alerts.emit('tt-gift',v[0],v[2],v[1])
        for _ in range(100):
            try:k,v=self.alert_feed.events.get_nowait()
            except queue.Empty:break
            if k=='alert' and self.twitch:self.overlay_server.alerts.emit(*v)
            elif k=='status':self.log(v)
        s=self.tiktok_panel.stats;self.statsvar.set(f'Espectadores: {s.viewers if s.viewers is not None else "—"}   ·   Likes: {s.likes}   ·   Regalos: {s.gifts}   ·   Seguidores: {s.follows}');self.voicevar.set('Escuchando / iniciando' if self.audio_busy and not self.audio_stop.is_set() else 'Detenido');self.countvar.set(f'Muertes: {self.panel.deaths}   ·   Mensajes de chat: {len(self.messages)}');self.update_overlays();self.after(250,self.tick)
    def update_overlays(self):
        if self.follow_obj is not self.twitch:
            self.follow_obj=self.twitch;self.follow_result=None;self.follow_at=0;self.follow_busy=False;self.twlive.set('Directo: sin comprobar')
        for _ in range(10):
            try:obj,value,online=self.follow_queue.get_nowait()
            except queue.Empty:break
            if obj is self.twitch:self.follow_result=value;self.follow_busy=False;self.twlive.set("Directo: "+("en emisión" if online else "sin emisión" if online is False else "no se pudo comprobar"))
        if self.twitch and not self.follow_busy and time.monotonic()-self.follow_at>=30:
            self.follow_at=time.monotonic();self.follow_busy=True;obj=self.twitch
            def work():
                try:value=obj.latest_follower()
                except Exception:value=None
                try:online=obj.stream_live()
                except Exception:online=None
                self.follow_queue.put((obj,value,online))
            threading.Thread(target=work,daemon=True).start()
        s=self.tiktok_panel.stats;active=not self.demo and self.ttstatus.get().startswith('Conectado')
        self.overlay_server.publish({'likes':s.likes if active else None,'follow-tiktok':s.latest_follow if active else None,'follow-twitch':self.follow_result if self.twitch else None,'deaths':self.panel.deaths,'viewers':s.viewers if active else None,'gifts':s.gifts if active else None},self.app_theme)
    def close(self):self.alert_feed.stop.set();self.overlay_server.close();self.feed.stop.set();super().close()
