import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from pathlib import Path
import shutil, threading
from PIL import Image, ImageTk

ICONS=dict(zip(['Discord','YouTube','Instagram','Twitch','Clip','Silencia Discord','Activa Discord','Silencia mi micro','Activa mi micro','Suma una muerte','Resta una muerte','Reinicia contador','Mi PC','Encuesta','Inicia una apuesta','Finalizar apuesta','Cancela apuesta','Finaliza encuesta'],['💬','▶','📷','🎮','✂','🔇','🎧','🔇','🎙','☠','−','↺','💻','📊','🏆','✓','✕','■']))
EXTRA=['Encuesta','Inicia una apuesta','Finalizar apuesta','Cancela apuesta','Finaliza encuesta']

def editor(p):
    w=tk.Toplevel(p.app); w.title('Personalizar botones'); w.geometry('560x360')
    selected=tk.StringVar(value='Discord'); label=tk.StringVar(); symbol=tk.StringVar(); color=tk.StringVar(); filename=tk.StringVar()
    ttk.Label(w,text='Botón').pack(); combo=ttk.Combobox(w,textvariable=selected,values=p.commands,state='readonly'); combo.pack(fill='x',padx=15)
    for title,var in [('Nombre visible',label),('Icono (emoji o texto)',symbol),('Color de fondo (#RRGGBB)',color),('Imagen local',filename)]:
        ttk.Label(w,text=title).pack(); ttk.Entry(w,textvariable=var).pack(fill='x',padx=15)
    def load(*_):
        c=selected.get(); d=p.custom.get(c,{}); label.set(d.get('label',c)); symbol.set(d.get('symbol',ICONS.get(c,''))); color.set(d.get('color','#27272e')); filename.set(d.get('image',''))
    def choose():
        f=filedialog.askopenfilename(parent=w,filetypes=[('Imágenes','*.png *.jpg *.jpeg *.webp *.ico *.bmp')]);
        if not f:return
        try:
            folder=p.base/'icons'; folder.mkdir(exist_ok=True); target=folder/(f'button_{p.commands.index(selected.get())}.png')
            with Image.open(f) as im:
                im.thumbnail((160,160)); im.convert('RGBA').save(target)
            filename.set(str(target.relative_to(p.base)))
        except Exception as e: messagebox.showerror('Imagen',str(e),parent=w)
    def save():
        try: w.winfo_rgb(color.get())
        except tk.TclError: messagebox.showerror('Color','Color no válido.',parent=w);return
        p.custom[selected.get()]={'label':label.get() or selected.get(),'symbol':symbol.get(),'color':color.get(),'image':filename.get()}; p.save(); p.refresh_buttons(); p.app.log('Botón personalizado: '+selected.get())
    ttk.Button(w,text='Elegir imagen',command=choose).pack(); ttk.Button(w,text='Quitar imagen',command=lambda:filename.set('')).pack(); ttk.Button(w,text='Guardar botón',command=save).pack()
    def reset(): p.custom.pop(selected.get(),None);p.save();load();p.refresh_buttons()
    ttk.Button(w,text='Restaurar botón',command=reset).pack(); combo.bind('<<ComboboxSelected>>',load);load()

def action(p,c,force_test=False):
    a=p.app
    if force_test or not a.live.get() or not a.twitch: a.log('SIMULACIÓN Twitch: '+c+' (activa modo real para ejecutar)');return
    if a.busy: a.log('Twitch ocupado; vuelve a pulsar.');return
    obj=a.twitch
    if c!='Clip' and obj.sender!=obj.broadcaster: a.log('Autoriza Croonan74 como propietario para encuestas y predicciones.');return
    payload={}
    if c in ('Encuesta','Inicia una apuesta'):
        pred=c!='Encuesta'; title=simpledialog.askstring(c,'Pregunta (máx. 45 para predicción / 60 para encuesta):',initialvalue='¿Ganaré esta partida?',parent=a)
        if not title:return
        choices=simpledialog.askstring(c,'Opciones separadas por coma:',initialvalue='Sí, No',parent=a)
        if choices is None:return
        opts=[x.strip() for x in choices.split(',') if x.strip()]
        if not 2<=len(opts)<=(10 if pred else 5) or len(set(opts))!=len(opts) or len(title)>(45 if pred else 60) or any(len(x)>(25) for x in opts): messagebox.showerror(c,'Pregunta u opciones no válidas.',parent=a);return
        duration=simpledialog.askinteger(c,'Duración en segundos:',initialvalue=60,minvalue=1 if pred else 15,maxvalue=1800,parent=a)
        if duration is None:return
        payload={'title':title,'outcomes' if pred else 'choices':[{'title':x} for x in opts],'prediction_window' if pred else 'duration':duration}
    if c=='Finalizar apuesta':
        # Select from fresh Twitch results, not a guessed outcome.
        a.busy=True
        def fetch():
            try: a.events.put(('prediction_pick',(obj,obj.current('predictions'))))
            except Exception as e:a.events.put(('extra_result',(False,str(e))))
        threading.Thread(target=fetch,daemon=True).start();return
    if not messagebox.askyesno('Confirmar Twitch',f'¿Ejecutar {c} en Croonan74?',parent=a):return
    submit(a,obj,c,payload)

def pick(a,obj,data):
    a.busy=False
    if obj is not a.twitch or not a.live.get():return
    if not data:a.log('No hay predicción activa.');return
    w=tk.Toplevel(a);w.title('Resolver predicción');w.grab_set();ttk.Label(w,text=data['title']).pack(padx=15,pady=10)
    def choose(out):
        if a.busy or obj is not a.twitch or not a.live.get():return
        if messagebox.askyesno('Confirmar ganador',f"¿Resolver a favor de {out['title']}?",parent=w):w.destroy();submit(a,obj,'Finalizar apuesta',{'id':data['id'],'winning_outcome_id':out['id']})
    for out in data['outcomes']:ttk.Button(w,text=out['title'],command=lambda o=out:choose(o)).pack(fill='x',padx=15,pady=3)

def submit(a,obj,c,payload):
    if obj is not a.twitch or not a.live.get() or a.busy:return
    a.busy=True
    def work():
        try: a.events.put(('extra_result',(True,obj.action(c,payload))))
        except Exception as e:a.events.put(('extra_result',(False,str(e))))
    threading.Thread(target=work,daemon=True).start()
