$ErrorActionPreference = 'Stop'
$AppRoot = Join-Path $PSScriptRoot 'programa'
$Py = (Get-Command py -ErrorAction SilentlyContinue)
if (-not $Py) { throw 'Instala Python 3.12 para Windows y vuelve a ejecutar este script.' }
Push-Location $AppRoot
try {
  & py -3.12 -m pip install --upgrade pip pyinstaller
  if ($LASTEXITCODE -ne 0) { throw 'No se pudo preparar PyInstaller.' }
  & py -3.12 -m pip install -r requirements.txt
  if ($LASTEXITCODE -ne 0) { throw 'No se pudieron instalar las dependencias.' }
  # Package the Spanish offline speech model so the installed app works without a first-run download.
  & py -3.12 .\descargar_modelo.py
  if ($LASTEXITCODE -ne 0) { throw 'No se pudo descargar el modelo de voz.' }
  # Build a normal Windows folder app: Python and dependencies are bundled; no Python install is needed by end users.
  & py -3.12 -m PyInstaller --noconfirm --clean --onedir --windowed --name EclipseBot --icon assets/eclipsebot.ico --add-data 'assets;assets' --add-data 'models;models' --collect-all vosk --collect-all sounddevice --collect-all pystray --collect-all pyautogui --collect-all websocket --hidden-import=PIL._tkinter_finder app.py
  if ($LASTEXITCODE -ne 0) { throw 'PyInstaller no pudo generar EclipseBot.exe.' }
  $IsccCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'),
    (Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe')
  )
  $Iscc = $IsccCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $Iscc) { throw 'La app ya está en programa\dist\EclipseBot. Instala Inno Setup 6 y ejecuta este script otra vez para crear el instalador.' }
  & $Iscc (Join-Path $PSScriptRoot 'installer\EclipseBot.iss')
  if ($LASTEXITCODE -ne 0) { throw 'Inno Setup no pudo compilar el instalador.' }
  Write-Host 'Instalador creado en release\EclipseBot-Setup.exe'
}
finally { Pop-Location }
